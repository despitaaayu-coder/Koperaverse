import React, {
  useState,
  useEffect,
  useRef,
  createContext,
  useContext,
  useMemo,
} from 'react';
import * as THREE from 'three';
import {
  Building2,
  Users,
  Wallet,
  ShoppingBag,
  GraduationCap,
  Vote,
  MessageSquare,
  Rocket,
  HelpCircle,
  ShieldCheck,
  BarChart3,
  FileSpreadsheet,
  History,
  Eye,
  UserCheck,
  ArrowLeft,
  Home,
  LogOut,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  XCircle,
  Sparkles,
  Gamepad2,
  LayoutDashboard,
  User,
  ChevronRight,
  Bell,
  Send,
  Award,
  Calendar,
  CreditCard,
  TrendingUp,
  Package,
  Sliders,
  Volume2,
  Navigation,
  Compass,
  MapPin,
  Menu,
  X,
  Star,
  Clock,
  DollarSign,
  PieChart,
  AlertTriangle,
  Check,
  Briefcase,
  BookOpen,
} from 'lucide-react';

// ============================================================================
// PALET WARNA WAJIB KOPERAVERSE
// ============================================================================
const COLORS = {
  lavender: '#A49BE1',
  purple: '#9784CE',
  deepNavy: '#352C74',
  softCyan: '#D1EBEF',
  white: '#FFFFFF',
};

// ============================================================================
// INITIAL DUMMY DATA (TERHUBUNG ANTAR ROLE)
// ============================================================================
const INITIAL_MEMBERS = [
  {
    id: 'MBR-001',
    name: 'Raka Pratama',
    email: 'raka.pratama@koperaverse.id',
    phone: '0812-3456-7890',
    joinDate: '2024-02-15',
    status: 'Aktif',
    unitUsaha: 'Kopi Arabika Gayo & Roastery',
    simpananPokok: 1000000,
    simpananWajib: 3600000,
    simpananSukarela: 8450000,
    pinjamanAktif: 5000000,
    poinAktivitas: 1280,
    avatar: {
      skin: '#F5CBA7',
      shirt: '#9784CE',
      pants: '#352C74',
      hair: '#2C221E',
      hat: 'crown',
      title: 'Wirausaha Muda',
    },
  },
  {
    id: 'MBR-002',
    name: 'Siti Aminah',
    email: 'siti.aminah@koperaverse.id',
    phone: '0813-9876-5432',
    joinDate: '2023-11-10',
    status: 'Aktif',
    unitUsaha: 'Tenun & Kriya Nusantara',
    simpananPokok: 1000000,
    simpananWajib: 4800000,
    simpananSukarela: 12200000,
    pinjamanAktif: 0,
    poinAktivitas: 1640,
    avatar: {
      skin: '#E0AC69',
      shirt: '#A49BE1',
      pants: '#352C74',
      hair: '#1B1B1B',
      hat: 'visor',
      title: 'Pengrajin Unggulan',
    },
  },
  {
    id: 'MBR-003',
    name: 'Budi Santoso',
    email: 'budi.santoso@koperaverse.id',
    phone: '0857-1122-3344',
    joinDate: '2024-05-03',
    status: 'Aktif',
    unitUsaha: 'Hidroponik Sayur Organik',
    simpananPokok: 1000000,
    simpananWajib: 2400000,
    simpananSukarela: 4100000,
    pinjamanAktif: 3000000,
    poinAktivitas: 890,
    avatar: {
      skin: '#D2996C',
      shirt: '#352C74',
      pants: '#9784CE',
      hair: '#3B2F2F',
      hat: 'none',
      title: 'Petani Urban',
    },
  },
];

const INITIAL_APPLICANTS = [
  {
    id: 'REG-2026-01',
    name: 'Nadia Kusuma',
    nik: '3201056708990004',
    email: 'nadia.kusuma@email.com',
    phone: '0821-4455-6677',
    unitUsaha: 'Bakery & Kue Tradisional Modern',
    setoranAwal: 1500000,
    tanggalDaftar: '2026-11-12',
    status: 'Menunggu Verifikasi',
  },
];

const INITIAL_PRODUCTS = [
  {
    id: 'PRD-01',
    name: 'Kopi Arabika Specialty 250g',
    seller: 'Raka Pratama',
    category: 'Kuliner & Minuman',
    price: 85000,
    stock: 42,
    rating: 4.9,
    badge: 'Terlaris',
    color: '#352C74',
    desc: 'Biji kopi pilihan hasil panen petani mitra koperasi dengan sangrai medium-dark aromatik.',
  },
  {
    id: 'PRD-02',
    name: 'Tas Selempang Tenun Etnik',
    seller: 'Siti Aminah',
    category: 'Kriya & Fashion',
    price: 245000,
    stock: 18,
    rating: 4.8,
    badge: 'Produk Unggulan',
    color: '#9784CE',
    desc: 'Tenun tangan asli bermotif geometris modern dengan lapisan dalam tahan air.',
  },
  {
    id: 'PRD-03',
    name: 'Paket Sayur Hidroponik Segar',
    seller: 'Budi Santoso',
    category: 'Pertanian & Pangan',
    price: 45000,
    stock: 65,
    rating: 4.7,
    badge: 'Organik',
    color: '#A49BE1',
    desc: 'Kombinasi selada romaine, pakcoy, dan kale bebas pestisida dipanen pagi hari.',
  },
  {
    id: 'PRD-04',
    name: 'Madu Hutan Murni Multiflora 500ml',
    seller: 'Koperasi Unit Tani',
    category: 'Kuliner & Minuman',
    price: 120000,
    stock: 30,
    rating: 5.0,
    badge: 'Sertifikat Halal',
    color: '#352C74',
    desc: 'Madu murni tanpa campuran pemanis buatan dari kelompok tani hutan lestari.',
  },
  {
    id: 'PRD-05',
    name: 'Software Kasir UMKM Koperapos',
    seller: 'Tim Tech Koperaverse',
    category: 'Jasa & Digital',
    price: 150000,
    stock: 99,
    rating: 4.9,
    badge: 'Digital',
    color: '#9784CE',
    desc: 'Lisensi 1 tahun aplikasi kasir & pembukuan otomatis terintegrasi laporan koperasi.',
  },
  {
    id: 'PRD-06',
    name: 'Keripik Tempe Sagu Renyah',
    seller: 'Nadia Kusuma',
    category: 'Kuliner & Minuman',
    price: 28000,
    stock: 80,
    rating: 4.6,
    badge: 'UMKM Baru',
    color: '#A49BE1',
    desc: 'Camilan gurih berprotein tinggi dengan bumbu rempah Nusantara tanpa MSG.',
  },
];

const INITIAL_COURSES = [
  {
    id: 'CRS-01',
    title: 'Dasar-Dasar Perkoperasian & Ekonomi Gotong Royong',
    instructor: 'Dr. Hendra Wijaya',
    category: 'Wajib Anggota',
    duration: '2 Jam',
    level: 'Pemula',
    points: 150,
    enrolled: true,
    progress: 100,
    modules: [
      'Nilai & Prinsip Koperasi',
      'Hak & Kewajiban Anggota',
      'Mekanisme RAT & SHU',
    ],
  },
  {
    id: 'CRS-02',
    title: 'Manajemen Keuangan & Pembukuan Digital UMKM',
    instructor: 'Maya Sari, CPA',
    category: 'Keuangan',
    duration: '3.5 Jam',
    level: 'Menengah',
    points: 250,
    enrolled: true,
    progress: 60,
    modules: [
      'Pemisahan Kas Pribadi & Usaha',
      'Laporan Laba Rugi Sederhana',
      'Perhitungan HPP & Margin',
    ],
  },
  {
    id: 'CRS-03',
    title: 'Digital Marketing & Branding Produk Koperasi',
    instructor: 'Dimas Anggara',
    category: 'Pemasaran',
    duration: '2.5 Jam',
    level: 'Semua Level',
    points: 200,
    enrolled: false,
    progress: 0,
    modules: [
      'Fotografi Produk dengan Smartphone',
      'Copywriting Marketplace',
      'Strategi Live Commerce',
    ],
  },
  {
    id: 'CRS-04',
    title: 'Ekspor Produk UMKM & Standar Kualitas Global',
    instructor: 'Ratna Dewi',
    category: 'Ekspor & Skala Usaha',
    duration: '4 Jam',
    level: 'Lanjutan',
    points: 350,
    enrolled: false,
    progress: 0,
    modules: [
      'Sertifikasi & Legalitas Ekspor',
      'Kemasan Standar Internasional',
      'Negosiasi Buyer B2B',
    ],
  },
];

const INITIAL_TRANSACTIONS = [
  {
    id: 'TRX-901',
    date: '2026-11-13 09:15',
    member: 'Raka Pratama',
    type: 'Simpanan Sukarela',
    amount: 1500000,
    status: 'Selesai',
  },
  {
    id: 'TRX-902',
    date: '2026-11-12 16:40',
    member: 'Siti Aminah',
    type: 'Pembelian Marketplace',
    amount: -245000,
    status: 'Selesai',
  },
  {
    id: 'TRX-903',
    date: '2026-11-11 11:20',
    member: 'Budi Santoso',
    type: 'Angsuran Pinjaman',
    amount: -550000,
    status: 'Selesai',
  },
  {
    id: 'TRX-904',
    date: '2026-11-10 14:05',
    member: 'Raka Pratama',
    type: 'Pengajuan Pinjaman Modal',
    amount: 4000000,
    status: 'Menunggu Persetujuan',
  },
];

const INITIAL_POLLS = [
  {
    id: 'POLL-01',
    title: 'Alokasi Dana Pengembangan Platform Digital & Inkubator UMKM 2027',
    desc: 'Persetujuan penggunaan 15% dana cadangan koperasi untuk peningkatan infrastruktur marketplace dan pelatihan pemuda.',
    deadline: '20 Nov 2026',
    votedOption: null,
    options: [
      { id: 'opt1', label: 'Setuju Penuh (15% Dana Cadangan)', votes: 142 },
      { id: 'opt2', label: 'Setuju Bertahap (10% Tahap Awal)', votes: 58 },
      { id: 'opt3', label: 'Tunda Hingga Evaluasi Semester I', votes: 14 },
    ],
  },
  {
    id: 'POLL-02',
    title: 'Penetapan Bunga Pinjaman Produktif Mikro Anggota Baru',
    desc: 'Usulan penurunan jasa pinjaman modal kerja usaha rintisan menjadi 0.6% flat per bulan.',
    deadline: '25 Nov 2026',
    votedOption: null,
    options: [
      { id: 'optA', label: 'Setuju (0.6% Flat / Bulan)', votes: 178 },
      { id: 'optB', label: 'Tetap di 0.8% Flat / Bulan', votes: 36 },
    ],
  },
];

const INITIAL_COMMUNITY_POSTS = [
  {
    id: 'POST-01',
    author: 'Siti Aminah',
    badge: 'Pengrajin Unggulan',
    time: '2 jam lalu',
    group: 'Kriya & Ekspor',
    content:
      'Alhamdulillah, minggu ini pesanan tas tenun dari Marketplace Koperaverse tembus 35 pcs! Terima kasih teman-teman yang sudah bantu share katalognya.',
    likes: 24,
    liked: false,
    comments: [
      {
        author: 'Raka Pratama',
        text: 'Selamat Bu Siti! Kualitas tenunnya memang juara.',
      },
    ],
  },
  {
    id: 'POST-02',
    author: 'Budi Santoso',
    badge: 'Petani Urban',
    time: '5 jam lalu',
    group: 'Agribisnis & Pangan',
    content:
      'Ada rekan anggota yang butuh pasokan selada dan pakcoy rutin untuk usaha kuliner/kafe? Kebun hidroponik kami siap suplai harga khusus sesama anggota.',
    likes: 19,
    liked: false,
    comments: [],
  },
];

const INITIAL_MENTORS = [
  {
    id: 'MNT-1',
    name: 'Ir. Bagus Prakoso',
    role: 'Eksportir & Supply Chain',
    slots: ['Senin, 14:00', 'Rabu, 10:00', 'Jumat, 15:30'],
    booked: null,
  },
  {
    id: 'MNT-2',
    name: 'Clara Wijaya, MBA',
    role: 'Venture & Pitch Deck Coach',
    slots: ['Selasa, 11:00', 'Kamis, 14:00'],
    booked: null,
  },
  {
    id: 'MNT-3',
    name: 'Fajar Nugroho',
    role: 'Digital Product & Tech Startup',
    slots: ['Rabu, 16:00', 'Sabtu, 10:00'],
    booked: null,
  },
];

const INITIAL_AUDIT_LOGS = [
  {
    id: 'AUD-105',
    time: '2026-11-13 09:15:22',
    actor: 'Raka Pratama (Anggota)',
    module: 'Financial Center',
    action: 'Setoran Simpanan Sukarela Rp 1.500.000',
    status: 'Valid',
  },
  {
    id: 'AUD-104',
    time: '2026-11-12 18:02:10',
    actor: 'Pengurus Utama',
    module: 'SHU & Keuangan',
    action: 'Simulasi parameter pembagian SHU Tahun Buku 2026',
    status: 'Valid',
  },
  {
    id: 'AUD-103',
    time: '2026-11-12 14:30:45',
    actor: 'Nadia Kusuma (Nonanggota)',
    module: 'Pendaftaran',
    action: 'Pengajuan pendaftaran calon anggota baru REG-2026-01',
    status: 'Pending Review',
  },
  {
    id: 'AUD-102',
    time: '2026-11-11 10:12:00',
    actor: 'Dewan Pengawas',
    module: 'Audit & Kepatuhan',
    action: 'Verifikasi rasio likuiditas kas bulanan (148%)',
    status: 'Valid',
  },
];

// ============================================================================
// KONFIGURASI GEDUNG 3D & NPC DI DUNIA VIRTUAL KOPERAVERSE
// ============================================================================
const CITY_BUILDINGS = [
  {
    id: 'my-coop',
    name: 'Kantor Pusat & My Cooperative',
    shortName: 'My Cooperative',
    x: 0,
    z: -22,
    w: 12,
    h: 11,
    d: 9,
    color: '#352C74',
    roofColor: '#9784CE',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'my-coop',
    guestPage: 'info',
    desc: 'Pusat administrasi keanggotaan, simpanan pokok/wajib, dan kartu digital.',
    npc: {
      name: 'Bu Ratna (Admin Koperasi)',
      text: 'Selamat datang di Kantor Pusat! Cek status simpanan & kartu anggotamu di sini.',
    },
  },
  {
    id: 'financial',
    name: 'Financial Center (Simpan Pinjam)',
    shortName: 'Financial Center',
    x: -24,
    z: -10,
    w: 10,
    h: 13,
    d: 9,
    color: '#9784CE',
    roofColor: '#352C74',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'financial',
    guestPage: 'info',
    desc: 'Layanan simpanan sukarela, kalkulator & pengajuan pinjaman modal produktif.',
    npc: {
      name: 'Pak Ardi (Analis Kredit)',
      text: 'Butuh modal usaha berbunga rendah? Yuk hitung simulasi cicilan di Financial Center!',
    },
  },
  {
    id: 'marketplace',
    name: 'Koperaverse Marketplace Plaza',
    shortName: 'Marketplace',
    x: 24,
    z: -10,
    w: 11,
    h: 9,
    d: 10,
    color: '#A49BE1',
    roofColor: '#352C74',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'marketplace',
    guestPage: 'katalog',
    desc: 'Bursa produk UMKM anggota koperasi. Belanja & pasarkan produk unggulanmu!',
    npc: {
      name: 'Kak Tania (Kurator UMKM)',
      text: 'Lihat produk-produk kreatif anggota kami atau buka tokomu sendiri!',
    },
  },
  {
    id: 'academy',
    name: 'Cooperative Academy',
    shortName: 'Academy',
    x: -24,
    z: 14,
    w: 10,
    h: 10,
    d: 9,
    color: '#352C74',
    roofColor: '#A49BE1',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'academy',
    guestPage: 'edukasi',
    desc: 'Pusat literasi perkoperasian, inkubasi keterampilan bisnis, dan sertifikasi.',
    npc: {
      name: 'Prof. Hendra (Dekan Akademi)',
      text: 'Tingkatkan kompetensi usahamu dan kumpulkan poin aktivitas di Cooperative Academy!',
    },
  },
  {
    id: 'assembly',
    name: 'Assembly Hall (Balai RAT)',
    shortName: 'Assembly Hall',
    x: 0,
    z: 24,
    w: 13,
    h: 9,
    d: 9,
    color: '#9784CE',
    roofColor: '#D1EBEF',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'assembly',
    guestPage: 'info',
    desc: 'Ruang musyawarah digital, Rapat Anggota Tahunan (RAT), dan e-voting kebijakan.',
    npc: {
      name: 'Moderator RAT',
      text: 'Suaramu menentukan arah koperasi! Ikuti e-voting musyawarah yang sedang berlangsung.',
    },
  },
  {
    id: 'youth-hub',
    name: 'Community & Youth Hub',
    shortName: 'Youth & Community',
    x: 24,
    z: 14,
    w: 10,
    h: 10,
    d: 9,
    color: '#A49BE1',
    roofColor: '#9784CE',
    portalColor: '#D1EBEF',
    roleTarget: 'anggota',
    pageTarget: 'youth',
    guestPage: 'daftar',
    desc: 'Komunitas kolaborasi, mentoring startup pemuda, dan pusat bantuan anggota.',
    npc: {
      name: 'Leo (Mentor Startup)',
      text: 'Punya ide bisnis inovatif? Booking sesi mentoring 1-on-1 di Youth Hub!',
    },
  },
];

// ============================================================================
// CONTEXT GLOBAL APLIKASI (STATE TERINTEGRASI)
// ============================================================================
const AppContext = createContext(null);

const formatRupiah = (num) => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
  }).format(num || 0);
};

// ============================================================================
// KOMPONEN 3D ROBLOX-STYLE VIRTUAL CITY (THREE.JS)
// ============================================================================
function Koperaverse3DWorld({
  avatarConfig,
  onEnterBuilding,
  onTalkNPC,
  teleportTarget,
  clearTeleport,
  currentRole,
}) {
  const mountRef = useRef(null);
  const [nearbyBuilding, setNearbyBuilding] = useState(null);
  const [activeNpcBubble, setActiveNpcBubble] = useState(null);
  const [cameraHint, setCameraHint] = useState(true);

  // Refs untuk kontrol input agar tidak memicu re-render loop
  const keysRef = useRef({});
  const joystickRef = useRef({ dx: 0, dz: 0 });
  const playerPosRef = useRef(new THREE.Vector3(0, 0, 4));
  const playerRotRef = useRef(0);
  const cameraAngleRef = useRef({ yaw: 0, pitch: 0.42, distance: 22 });
  const isDraggingRef = useRef(false);
  const lastMouseRef = useRef({ x: 0, y: 0 });
  const playerGroupRef = useRef(null);
  const avatarPartsRef = useRef({});
  const sceneObjectsRef = useRef({ buildings: [], npcs: [] });

  // Update warna & aksesori avatar secara real-time saat user mengedit Avatar Customizer
  useEffect(() => {
    const parts = avatarPartsRef.current;
    if (!parts.torso) return;
    parts.head.material.color.set(avatarConfig.skin);
    parts.leftArm.material.color.set(avatarConfig.skin);
    parts.rightArm.material.color.set(avatarConfig.skin);
    parts.torso.material.color.set(avatarConfig.shirt);
    parts.leftLeg.material.color.set(avatarConfig.pants);
    parts.rightLeg.material.color.set(avatarConfig.pants);
    if (parts.hair) parts.hair.material.color.set(avatarConfig.hair);
    if (parts.crown) parts.crown.visible = avatarConfig.hat === 'crown';
    if (parts.visor) parts.visor.visible = avatarConfig.hat === 'visor';
  }, [avatarConfig]);

  // Teleport / jalan cepat ke gedung tertentu
  useEffect(() => {
    if (teleportTarget) {
      const b = CITY_BUILDINGS.find((item) => item.id === teleportTarget);
      if (b) {
        const offsetZ = b.z > 0 ? -7.5 : 7.5;
        playerPosRef.current.set(b.x, 0, b.z + offsetZ);
        setNearbyBuilding(b);
      }
      clearTeleport();
    }
  }, [teleportTarget, clearTeleport]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Setup Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#D1EBEF');
    scene.fog = new THREE.FogExp2('#D1EBEF', 0.0085);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 520;
    const camera = new THREE.PerspectiveCamera(52, width / height, 0.1, 300);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 2. Pencahayaan Cerah Gaya Roblox Virtual World
    const hemiLight = new THREE.HemisphereLight('#FFFFFF', '#A49BE1', 0.95);
    hemiLight.position.set(0, 50, 0);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight('#FFFFFF', 0.9);
    dirLight.position.set(28, 45, 25);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 5;
    dirLight.shadow.camera.far = 120;
    const d = 45;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    scene.add(dirLight);

    // 3. Lantai Kota, Taman & Jalan Raya Plaza
    const groundGeo = new THREE.PlaneGeometry(140, 140);
    const groundMat = new THREE.MeshLambertMaterial({ color: '#BCE3EA' });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Plaza Tengah Berbentuk Lingkaran & Jalur Salib
    const plazaMat = new THREE.MeshLambertMaterial({ color: '#FFFFFF' });
    const plazaCenter = new THREE.Mesh(
      new THREE.CylinderGeometry(12, 12, 0.15, 32),
      plazaMat
    );
    plazaCenter.position.y = 0.075;
    plazaCenter.receiveShadow = true;
    scene.add(plazaCenter);

    const ringMat = new THREE.MeshLambertMaterial({ color: '#A49BE1' });
    const plazaRing = new THREE.Mesh(
      new THREE.RingGeometry(10.5, 12, 32),
      ringMat
    );
    plazaRing.rotation.x = -Math.PI / 2;
    plazaRing.position.y = 0.16;
    scene.add(plazaRing);

    // Jalan Penghubung Antar Gedung
    const roadMat = new THREE.MeshLambertMaterial({ color: '#EAE7FA' });
    const roadNS = new THREE.Mesh(new THREE.BoxGeometry(6, 0.12, 56), roadMat);
    roadNS.position.y = 0.06;
    roadNS.receiveShadow = true;
    scene.add(roadNS);

    const roadEW = new THREE.Mesh(new THREE.BoxGeometry(58, 0.12, 6), roadMat);
    roadEW.position.set(0, 0.06, -10);
    roadEW.receiveShadow = true;
    scene.add(roadEW);

    const roadEW2 = new THREE.Mesh(new THREE.BoxGeometry(58, 0.12, 6), roadMat);
    roadEW2.position.set(0, 0.06, 14);
    roadEW2.receiveShadow = true;
    scene.add(roadEW2);

    // Air Mancur Ikonik Koperaverse di Tengah Plaza
    const fountainBase = new THREE.Mesh(
      new THREE.CylinderGeometry(3.4, 3.8, 0.8, 20),
      new THREE.MeshLambertMaterial({ color: '#352C74' })
    );
    fountainBase.position.y = 0.4;
    fountainBase.castShadow = true;
    scene.add(fountainBase);

    const fountainWater = new THREE.Mesh(
      new THREE.CylinderGeometry(3.1, 3.1, 0.85, 20),
      new THREE.MeshLambertMaterial({ color: '#D1EBEF' })
    );
    fountainWater.position.y = 0.42;
    scene.add(fountainWater);

    const fountainPillar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.6, 0.9, 2.8, 12),
      new THREE.MeshLambertMaterial({ color: '#9784CE' })
    );
    fountainPillar.position.y = 1.5;
    scene.add(fountainPillar);

    const crystalTop = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.95, 0),
      new THREE.MeshStandardMaterial({
        color: '#A49BE1',
        emissive: '#9784CE',
        emissiveIntensity: 0.4,
      })
    );
    crystalTop.position.y = 3.5;
    scene.add(crystalTop);

    // 4. Pohon Low-Poly & Bangku Taman
    const createLowPolyTree = (tx, tz) => {
      const tree = new THREE.Group();
      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.35, 0.5, 2.2, 6),
        new THREE.MeshLambertMaterial({ color: '#6D4C41' })
      );
      trunk.position.y = 1.1;
      trunk.castShadow = true;
      tree.add(trunk);

      const foliage1 = new THREE.Mesh(
        new THREE.DodecahedronGeometry(1.8, 0),
        new THREE.MeshLambertMaterial({ color: '#9784CE' })
      );
      foliage1.position.y = 2.9;
      foliage1.castShadow = true;
      tree.add(foliage1);

      const foliage2 = new THREE.Mesh(
        new THREE.DodecahedronGeometry(1.2, 0),
        new THREE.MeshLambertMaterial({ color: '#A49BE1' })
      );
      foliage2.position.set(0.5, 4.1, 0.3);
      tree.add(foliage2);

      tree.position.set(tx, 0, tz);
      scene.add(tree);
    };

    const treeCoords = [
      [-11, -3],
      [11, -3],
      [-11, 7],
      [11, 7],
      [-14, -20],
      [14, -20],
      [-14, 22],
      [14, 22],
      [-33, 0],
      [33, 0],
      [-33, -20],
      [33, -20],
    ];
    treeCoords.forEach(([tx, tz]) => createLowPolyTree(tx, tz));

    // 5. Bangun Gedung-Gedung Modern Low-Poly + Label 3D Sprite + Portal Interaktif
    const makeTextSprite = (
      message,
      bgHex = '#352C74',
      textHex = '#FFFFFF'
    ) => {
      const canvas = document.createElement('canvas');
      canvas.width = 512;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = bgHex;
      ctx.beginPath();
      ctx.roundRect(16, 16, 480, 96, 28);
      ctx.fill();
      ctx.strokeStyle = '#D1EBEF';
      ctx.lineWidth = 6;
      ctx.stroke();

      ctx.fillStyle = textHex;
      ctx.font = 'bold 30px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(message, 256, 66);

      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({
        map: texture,
        transparent: true,
      });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.scale.set(9.5, 2.4, 1);
      return sprite;
    };

    const buildingMeshes = [];
    const npcMeshes = [];

    CITY_BUILDINGS.forEach((b) => {
      const group = new THREE.Group();
      group.position.set(b.x, 0, b.z);

      // Badan Gedung Utama
      const bodyGeo = new THREE.BoxGeometry(b.w, b.h, b.d);
      const bodyMat = new THREE.MeshLambertMaterial({ color: b.color });
      const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
      bodyMesh.position.y = b.h / 2;
      bodyMesh.castShadow = true;
      bodyMesh.receiveShadow = true;
      bodyMesh.userData = { building: b };
      group.add(bodyMesh);
      buildingMeshes.push(bodyMesh);

      // Atap Modern Bertingkat
      const roofGeo = new THREE.BoxGeometry(b.w + 0.8, 1.2, b.d + 0.8);
      const roofMat = new THREE.MeshLambertMaterial({ color: b.roofColor });
      const roofMesh = new THREE.Mesh(roofGeo, roofMat);
      roofMesh.position.y = b.h + 0.6;
      roofMesh.castShadow = true;
      roofMesh.userData = { building: b };
      group.add(roofMesh);
      buildingMeshes.push(roofMesh);

      // Jendela Kaca Cyan Bercahaya
      const winMat = new THREE.MeshStandardMaterial({
        color: '#D1EBEF',
        emissive: '#D1EBEF',
        emissiveIntensity: 0.35,
      });
      const rows = Math.floor(b.h / 3.5);
      for (let r = 1; r <= rows; r++) {
        const winStrip = new THREE.Mesh(
          new THREE.BoxGeometry(b.w * 0.72, 1.1, b.d + 0.15),
          winMat
        );
        winStrip.position.y = r * 3.1;
        group.add(winStrip);
      }

      // Portal Masuk Bercahaya di Depan Gedung
      const portalZ = b.z > 0 ? -(b.d / 2 + 1.6) : b.d / 2 + 1.6;
      const portalRing = new THREE.Mesh(
        new THREE.CylinderGeometry(2.1, 2.1, 0.18, 24),
        new THREE.MeshStandardMaterial({
          color: '#D1EBEF',
          emissive: '#A49BE1',
          emissiveIntensity: 0.6,
        })
      );
      portalRing.position.set(0, 0.12, portalZ);
      portalRing.userData = { building: b };
      group.add(portalRing);
      buildingMeshes.push(portalRing);

      // Papan Nama Gedung Mengambang
      const label = makeTextSprite(b.shortName, '#352C74', '#FFFFFF');
      label.position.set(0, b.h + 3.2, 0);
      group.add(label);

      // Karakter NPC Penjaga Gedung
      const npcGroup = new THREE.Group();
      const npcX = b.x + (b.x >= 0 ? -3.2 : 3.2);
      const npcZ = b.z + (b.z > 0 ? -(b.d / 2 + 2.2) : b.d / 2 + 2.2);
      npcGroup.position.set(npcX, 0, npcZ);

      const npcBody = new THREE.Mesh(
        new THREE.BoxGeometry(1.1, 1.3, 0.65),
        new THREE.MeshLambertMaterial({ color: '#352C74' })
      );
      npcBody.position.y = 1.65;
      npcBody.castShadow = true;
      npcBody.userData = { npcBuilding: b };
      npcGroup.add(npcBody);
      npcMeshes.push(npcBody);

      const npcHead = new THREE.Mesh(
        new THREE.BoxGeometry(0.95, 0.95, 0.95),
        new THREE.MeshLambertMaterial({ color: '#F5CBA7' })
      );
      npcHead.position.y = 2.85;
      npcHead.userData = { npcBuilding: b };
      npcGroup.add(npcHead);
      npcMeshes.push(npcHead);

      const npcLegs = new THREE.Mesh(
        new THREE.BoxGeometry(1.0, 1.0, 0.6),
        new THREE.MeshLambertMaterial({ color: '#9784CE' })
      );
      npcLegs.position.y = 0.5;
      npcGroup.add(npcLegs);

      // Ikon Tanda Seru Interaksi NPC
      const marker = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.35, 0),
        new THREE.MeshStandardMaterial({
          color: '#D1EBEF',
          emissive: '#9784CE',
          emissiveIntensity: 0.7,
        })
      );
      marker.position.y = 3.9;
      npcGroup.add(marker);

      scene.add(npcGroup);
      scene.add(group);
    });

    sceneObjectsRef.current = { buildings: buildingMeshes, npcs: npcMeshes };

    // 6. Karakter Utama Avatar Roblox-Style Third-Person
    const player = new THREE.Group();
    playerGroupRef.current = player;

    const headMat = new THREE.MeshLambertMaterial({ color: avatarConfig.skin });
    const torsoMat = new THREE.MeshLambertMaterial({
      color: avatarConfig.shirt,
    });
    const pantsMat = new THREE.MeshLambertMaterial({
      color: avatarConfig.pants,
    });
    const hairMat = new THREE.MeshLambertMaterial({ color: avatarConfig.hair });

    const leftLeg = new THREE.Mesh(
      new THREE.BoxGeometry(0.52, 1.1, 0.55),
      pantsMat
    );
    leftLeg.position.set(-0.3, 0.55, 0);
    leftLeg.castShadow = true;
    player.add(leftLeg);

    const rightLeg = new THREE.Mesh(
      new THREE.BoxGeometry(0.52, 1.1, 0.55),
      pantsMat
    );
    rightLeg.position.set(0.3, 0.55, 0);
    rightLeg.castShadow = true;
    player.add(rightLeg);

    const torso = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 1.35, 0.65),
      torsoMat
    );
    torso.position.set(0, 1.78, 0);
    torso.castShadow = true;
    player.add(torso);

    const leftArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.45, 1.25, 0.5),
      headMat
    );
    leftArm.position.set(-0.88, 1.78, 0);
    leftArm.castShadow = true;
    player.add(leftArm);

    const rightArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.45, 1.25, 0.5),
      headMat
    );
    rightArm.position.set(0.88, 1.78, 0);
    rightArm.castShadow = true;
    player.add(rightArm);

    const head = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 1.0), headMat);
    head.position.set(0, 3.0, 0);
    head.castShadow = true;
    player.add(head);

    // Mata & Senyum Avatar Roblox
    const eyeMat = new THREE.MeshBasicMaterial({ color: '#1A1A1A' });
    const eyeL = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.18, 0.08),
      eyeMat
    );
    eyeL.position.set(-0.22, 3.05, 0.5);
    player.add(eyeL);
    const eyeR = new THREE.Mesh(
      new THREE.BoxGeometry(0.14, 0.18, 0.08),
      eyeMat
    );
    eyeR.position.set(0.22, 3.05, 0.5);
    player.add(eyeR);

    // Rambut Blocky
    const hair = new THREE.Mesh(
      new THREE.BoxGeometry(1.08, 0.35, 1.08),
      hairMat
    );
    hair.position.set(0, 3.52, -0.02);
    player.add(hair);

    // Aksesori Mahkota (Crown)
    const crown = new THREE.Mesh(
      new THREE.CylinderGeometry(0.45, 0.38, 0.35, 6),
      new THREE.MeshStandardMaterial({
        color: '#FFD54F',
        emissive: '#FFA000',
        emissiveIntensity: 0.3,
      })
    );
    crown.position.set(0, 3.82, 0);
    crown.visible = avatarConfig.hat === 'crown';
    player.add(crown);

    // Aksesori Visor Futuristik
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(1.06, 0.25, 0.25),
      new THREE.MeshStandardMaterial({
        color: '#D1EBEF',
        emissive: '#D1EBEF',
        emissiveIntensity: 0.6,
      })
    );
    visor.position.set(0, 3.08, 0.48);
    visor.visible = avatarConfig.hat === 'visor';
    player.add(visor);

    avatarPartsRef.current = {
      head,
      torso,
      leftArm,
      rightArm,
      leftLeg,
      rightLeg,
      hair,
      crown,
      visor,
    };
    player.position.copy(playerPosRef.current);
    scene.add(player);

    // 7. Event Listeners: Keyboard WASD/Arrows, Mouse Orbit & Raycast Klik Gedung/NPC
    const handleKeyDown = (e) => {
      if (
        ['INPUT', 'TEXTAREA', 'SELECT'].includes(
          document.activeElement?.tagName
        )
      )
        return;
      keysRef.current[e.code] = true;
    };
    const handleKeyUp = (e) => {
      keysRef.current[e.code] = false;
    };

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let pointerDownPos = { x: 0, y: 0 };

    const handlePointerDown = (e) => {
      isDraggingRef.current = true;
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      lastMouseRef.current = { x: clientX, y: clientY };
      pointerDownPos = { x: clientX, y: clientY };
      setCameraHint(false);
    };

    const handlePointerMove = (e) => {
      if (!isDraggingRef.current) return;
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      const dx = clientX - lastMouseRef.current.x;
      const dy = clientY - lastMouseRef.current.y;
      cameraAngleRef.current.yaw -= dx * 0.007;
      cameraAngleRef.current.pitch = Math.max(
        0.18,
        Math.min(1.05, cameraAngleRef.current.pitch + dy * 0.005)
      );
      lastMouseRef.current = { x: clientX, y: clientY };
    };

    const handlePointerUp = (e) => {
      isDraggingRef.current = false;
      const clientX = e.changedTouches
        ? e.changedTouches[0].clientX
        : e.clientX;
      const clientY = e.changedTouches
        ? e.changedTouches[0].clientY
        : e.clientY;
      const dist = Math.hypot(
        clientX - pointerDownPos.x,
        clientY - pointerDownPos.y
      );

      // Jika klik (bukan drag kamera), cek raycast gedung atau NPC
      if (dist < 8) {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);

        const npcHits = raycaster.intersectObjects(
          sceneObjectsRef.current.npcs,
          false
        );
        if (npcHits.length > 0 && npcHits[0].object.userData.npcBuilding) {
          const b = npcHits[0].object.userData.npcBuilding;
          setActiveNpcBubble(b);
          if (onTalkNPC) onTalkNPC(b);
          return;
        }

        const buildingHits = raycaster.intersectObjects(
          sceneObjectsRef.current.buildings,
          false
        );
        if (
          buildingHits.length > 0 &&
          buildingHits[0].object.userData.building
        ) {
          const b = buildingHits[0].object.userData.building;
          onEnterBuilding(b);
        }
      }
    };

    const handleWheel = (e) => {
      cameraAngleRef.current.distance = Math.max(
        12,
        Math.min(36, cameraAngleRef.current.distance + e.deltaY * 0.01)
      );
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    domElem.addEventListener('touchstart', handlePointerDown, {
      passive: true,
    });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });
    window.addEventListener('touchend', handlePointerUp);
    domElem.addEventListener('wheel', handleWheel, { passive: true });

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // 8. Animation Loop
    let animId;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Rotasi kristal air mancur
      crystalTop.rotation.y = elapsed * 1.4;
      crystalTop.position.y = 3.5 + Math.sin(elapsed * 2.5) * 0.18;

      // Gerakan Avatar (WASD / Arrows / Touch Joystick)
      let moveForward = 0;
      let moveRight = 0;
      const k = keysRef.current;
      if (k['KeyW'] || k['ArrowUp']) moveForward += 1;
      if (k['KeyS'] || k['ArrowDown']) moveForward -= 1;
      if (k['KeyA'] || k['ArrowLeft']) moveRight -= 1;
      if (k['KeyD'] || k['ArrowRight']) moveRight += 1;

      moveForward += joystickRef.current.dz;
      moveRight += joystickRef.current.dx;

      const isMoving =
        Math.abs(moveForward) > 0.05 || Math.abs(moveRight) > 0.05;
      if (isMoving) {
        const yaw = cameraAngleRef.current.yaw;
        const forwardVec = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
        const rightVec = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
        const dir = new THREE.Vector3()
          .addScaledVector(forwardVec, moveForward)
          .addScaledVector(rightVec, moveRight)
          .normalize();

        const speed = 0.24;
        const nextX = Math.max(
          -42,
          Math.min(42, playerPosRef.current.x + dir.x * speed)
        );
        const nextZ = Math.max(
          -36,
          Math.min(36, playerPosRef.current.z + dir.z * speed)
        );
        playerPosRef.current.set(nextX, 0, nextZ);

        const targetAngle = Math.atan2(dir.x, dir.z);
        playerRotRef.current = targetAngle;

        // Animasi Ayunan Kaki & Tangan Gaya Roblox
        const swing = Math.sin(elapsed * 11) * 0.55;
        avatarPartsRef.current.leftLeg.rotation.x = swing;
        avatarPartsRef.current.rightLeg.rotation.x = -swing;
        avatarPartsRef.current.leftArm.rotation.x = -swing * 0.8;
        avatarPartsRef.current.rightArm.rotation.x = swing * 0.8;
      } else {
        avatarPartsRef.current.leftLeg.rotation.x = 0;
        avatarPartsRef.current.rightLeg.rotation.x = 0;
        avatarPartsRef.current.leftArm.rotation.x = 0;
        avatarPartsRef.current.rightArm.rotation.x = 0;
      }

      player.position.copy(playerPosRef.current);
      player.rotation.y = playerRotRef.current;

      // Deteksi Jarak ke Gedung / Portal Terdekat
      let closest = null;
      let minDist = 11.5;
      for (const b of CITY_BUILDINGS) {
        const portalZ = b.z > 0 ? b.z - (b.d / 2 + 1.6) : b.z + (b.d / 2 + 1.6);
        const dist = Math.hypot(
          playerPosRef.current.x - b.x,
          playerPosRef.current.z - portalZ
        );
        if (dist < minDist) {
          minDist = dist;
          closest = b;
        }
      }
      setNearbyBuilding(closest);

      // Update Posisi Kamera Third-Person Mengikuti Avatar
      const { yaw, pitch, distance } = cameraAngleRef.current;
      const camX =
        playerPosRef.current.x + distance * Math.sin(yaw) * Math.cos(pitch);
      const camY = playerPosRef.current.y + 2.5 + distance * Math.sin(pitch);
      const camZ =
        playerPosRef.current.z + distance * Math.cos(yaw) * Math.cos(pitch);
      camera.position.lerp(new THREE.Vector3(camX, camY, camZ), 0.14);
      camera.lookAt(
        playerPosRef.current.x,
        playerPosRef.current.y + 2.2,
        playerPosRef.current.z
      );

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      domElem.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      domElem.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
      domElem.removeEventListener('wheel', handleWheel);
      window.removeEventListener('resize', handleResize);
      if (container.contains(domElem)) {
        container.removeChild(domElem);
      }
      renderer.dispose();
    };
  }, []);

  // Helper D-Pad untuk perangkat layar sentuh / mouse click
  const setPad = (dx, dz) => {
    joystickRef.current = { dx, dz };
  };

  return (
    <div
      className="relative w-full h-[540px] sm:h-[600px] rounded-3xl overflow-hidden shadow-2xl border-4 border-white select-none"
      style={{ backgroundColor: COLORS.softCyan }}
    >
      {/* Canvas 3D Three.js */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* HUD Kiri Atas: Info Dunia & Kontrol */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 max-w-xs pointer-events-none">
        <div className="backdrop-blur-md bg-[#352C74]/90 text-white px-4 py-2.5 rounded-2xl shadow-lg border border-white/20">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D1EBEF] animate-ping" />
            <span className="font-bold text-sm tracking-wide">
              KOPERAVERSE 3D CITY
            </span>
          </div>
          <p className="text-xs text-[#D1EBEF] mt-0.5">
            Klik gedung mana saja untuk masuk, atau gerakkan avatar dengan{' '}
            <span className="font-bold text-white">WASD / Panah</span>.
          </p>
        </div>

        {cameraHint && (
          <div className="bg-white/90 text-[#352C74] px-3 py-1.5 rounded-xl text-xs font-semibold shadow flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-[#9784CE]" />
            Geser layar untuk memutar kamera 360°
          </div>
        )}
      </div>

      {/* HUD Kanan Atas: Fast-Travel Teleport Menu */}
      <div className="absolute top-4 right-4 flex flex-col gap-1.5 z-10">
        <div className="bg-white/95 backdrop-blur-md p-2 rounded-2xl shadow-lg border border-[#A49BE1]/40">
          <p className="text-[11px] font-extrabold uppercase tracking-wider text-[#352C74] px-2 pb-1 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-[#9784CE]" /> Teleport Gedung
          </p>
          <div className="grid grid-cols-1 gap-1 max-h-52 overflow-y-auto">
            {CITY_BUILDINGS.map((b) => (
              <button
                key={b.id}
                onClick={() => onEnterBuilding(b)}
                className="text-left text-xs font-semibold px-2.5 py-1.5 rounded-xl text-[#352C74] hover:bg-[#9784CE] hover:text-white transition flex items-center justify-between gap-2"
              >
                <span className="truncate">{b.shortName}</span>
                <ChevronRight className="w-3.5 h-3.5 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Popup Dialog NPC saat diklik */}
      {activeNpcBubble && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-20 w-[90%] max-w-md bg-white rounded-2xl shadow-2xl border-2 border-[#9784CE] p-4 animate-bounce-once">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#352C74] text-white flex items-center justify-center font-bold">
                NPC
              </div>
              <div>
                <h4 className="font-bold text-sm text-[#352C74]">
                  {activeNpcBubble.npc.name}
                </h4>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-[#D1EBEF] text-[#352C74]">
                  {activeNpcBubble.shortName}
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveNpcBubble(null)}
              className="p-1 rounded-lg hover:bg-gray-100 text-[#352C74]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-sm text-gray-700 mt-2.5 leading-relaxed">
            "{activeNpcBubble.npc.text}"
          </p>
          <div className="mt-3 flex justify-end gap-2">
            <button
              onClick={() => setActiveNpcBubble(null)}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-600 hover:bg-gray-100"
            >
              Tutup
            </button>
            <button
              onClick={() => {
                const target = activeNpcBubble;
                setActiveNpcBubble(null);
                onEnterBuilding(target);
              }}
              className="px-4 py-1.5 rounded-xl text-xs font-bold bg-[#352C74] text-white hover:bg-[#9784CE] transition flex items-center gap-1"
            >
              Masuk ke {activeNpcBubble.shortName}{' '}
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Prompt Portal Gedung Terdekat (Bottom Center) */}
      {nearbyBuilding && (
        <div className="absolute bottom-24 sm:bottom-6 left-1/2 -translate-x-1/2 z-20 w-[92%] max-w-md bg-[#352C74]/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border-2 border-[#D1EBEF] flex items-center justify-between gap-3">
          <div>
            <span className="text-[10px] uppercase tracking-wider font-bold text-[#D1EBEF]">
              Portal Gedung Terdeteksi
            </span>
            <h4 className="font-extrabold text-base leading-tight">
              {nearbyBuilding.name}
            </h4>
            <p className="text-xs text-white/80 line-clamp-1 mt-0.5">
              {nearbyBuilding.desc}
            </p>
          </div>
          <button
            onClick={() => onEnterBuilding(nearbyBuilding)}
            className="shrink-0 px-4 py-2.5 rounded-xl bg-[#D1EBEF] text-[#352C74] font-extrabold text-xs hover:bg-white transition shadow-md flex items-center gap-1.5"
          >
            Masuk Gedung <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Kontrol Navigasi D-Pad Alternatif (Mobile & Mouse Friendly) */}
      <div className="absolute bottom-4 left-4 z-10 flex flex-col items-center gap-1 bg-white/85 backdrop-blur-md p-2 rounded-2xl shadow-lg border border-[#A49BE1]/40">
        <button
          onMouseDown={() => setPad(0, 1)}
          onMouseUp={() => setPad(0, 0)}
          onMouseLeave={() => setPad(0, 0)}
          onTouchStart={() => setPad(0, 1)}
          onTouchEnd={() => setPad(0, 0)}
          aria-label="Maju"
          className="w-10 h-10 rounded-xl bg-[#352C74] text-white font-bold flex items-center justify-center active:bg-[#9784CE] shadow"
        >
          ▲
        </button>
        <div className="flex gap-1">
          <button
            onMouseDown={() => setPad(-1, 0)}
            onMouseUp={() => setPad(0, 0)}
            onMouseLeave={() => setPad(0, 0)}
            onTouchStart={() => setPad(-1, 0)}
            onTouchEnd={() => setPad(0, 0)}
            aria-label="Kiri"
            className="w-10 h-10 rounded-xl bg-[#352C74] text-white font-bold flex items-center justify-center active:bg-[#9784CE] shadow"
          >
            ◀
          </button>
          <button
            onMouseDown={() => setPad(0, -1)}
            onMouseUp={() => setPad(0, 0)}
            onMouseLeave={() => setPad(0, 0)}
            onTouchStart={() => setPad(0, -1)}
            onTouchEnd={() => setPad(0, 0)}
            aria-label="Mundur"
            className="w-10 h-10 rounded-xl bg-[#352C74] text-white font-bold flex items-center justify-center active:bg-[#9784CE] shadow"
          >
            ▼
          </button>
          <button
            onMouseDown={() => setPad(1, 0)}
            onMouseUp={() => setPad(0, 0)}
            onMouseLeave={() => setPad(0, 0)}
            onTouchStart={() => setPad(1, 0)}
            onTouchEnd={() => setPad(0, 0)}
            aria-label="Kanan"
            className="w-10 h-10 rounded-xl bg-[#352C74] text-white font-bold flex items-center justify-center active:bg-[#9784CE] shadow"
          >
            ▶
          </button>
        </div>
      </div>

      {/* Mode Badge di Kanan Bawah */}
      <div className="hidden sm:flex absolute bottom-4 right-4 bg-white/90 text-[#352C74] px-3.5 py-2 rounded-2xl text-xs font-bold shadow items-center gap-2">
        <Gamepad2 className="w-4 h-4 text-[#9784CE]" />
        <span>Mode Eksplorasi Avatar ({currentRole.toUpperCase()})</span>
      </div>
    </div>
  );
}

// ============================================================================
// KOMPONEN HALAMAN LOGIN & PEMILIHAN ROLE
// ============================================================================
function LoginScreen({ onLogin }) {
  const [selectedRole, setSelectedRole] = useState('anggota');
  const [email, setEmail] = useState('raka.pratama@koperaverse.id');
  const [name, setName] = useState('Raka Pratama');

  const rolePresets = [
    {
      id: 'nonanggota',
      title: 'Nonanggota / Publik',
      subtitle:
        'Jelajahi katalog UMKM, edukasi koperasi, & daftar jadi anggota baru',
      defaultName: 'Pengunjung Koperaverse',
      defaultEmail: 'tamu@koperaverse.id',
      icon: Compass,
      badge: 'Akses Terbuka',
    },
    {
      id: 'anggota',
      title: 'Anggota Koperasi',
      subtitle:
        'Akses kota 3D penuh, simpan pinjam, marketplace, RAT, & akademi',
      defaultName: 'Raka Pratama',
      defaultEmail: 'raka.pratama@koperaverse.id',
      icon: UserCheck,
      badge: 'Fitur Lengkap',
    },
    {
      id: 'pengurus',
      title: 'Pengurus / Pengawas',
      subtitle:
        'Kelola anggota, verifikasi pinjaman, kalkulasi SHU, laporan & audit',
      defaultName: 'Dewan Pengurus Utama',
      defaultEmail: 'pengurus@koperaverse.id',
      icon: ShieldCheck,
      badge: 'Admin & Tata Kelola',
    },
  ];

  const handleSelectPreset = (preset) => {
    setSelectedRole(preset.id);
    setName(preset.defaultName);
    setEmail(preset.defaultEmail);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin({
      role: selectedRole,
      name: name.trim() || 'Pengguna Koperaverse',
      email,
    });
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 sm:p-8"
      style={{
        background: `linear-gradient(135deg, ${COLORS.deepNavy} 0%, ${COLORS.purple} 55%, ${COLORS.softCyan} 100%)`,
      }}
    >
      <div className="w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 border-4 border-white">
        {/* Panel Kiri: Branding & Visual Roblox World */}
        <div
          className="lg:col-span-5 p-8 text-white flex flex-col justify-between relative overflow-hidden"
          style={{ backgroundColor: COLORS.deepNavy }}
        >
          <div className="relative z-10">
            <div
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-extrabold tracking-wider uppercase mb-5"
              style={{
                backgroundColor: COLORS.softCyan,
                color: COLORS.deepNavy,
              }}
            >
              <Gamepad2 className="w-4 h-4" /> Digital Cooperative Metaverse
            </div>
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight leading-tight">
              KOPERAVERSE
            </h1>
            <p className="text-sm text-[#D1EBEF] mt-3 leading-relaxed">
              Ekosistem koperasi digital interaktif bergaya dunia virtual 3D.
              Bangun ekonomi gotong royong, kelola simpan pinjam, pasarkan
              produk UMKM, dan ikuti musyawarah secara transparan.
            </p>
          </div>

          {/* Kartu Ilustrasi Mini Kota */}
          <div className="my-6 p-4 rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#D1EBEF] font-semibold">
                Total Aset Ekosistem
              </span>
              <span className="font-extrabold text-white">Rp 4,85 Miliar</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#D1EBEF] font-semibold">
                Anggota Aktif Terhubung
              </span>
              <span className="font-extrabold text-white">1.248 Anggota</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#D1EBEF] font-semibold">
                Gedung Virtual Interaktif
              </span>
              <span className="font-extrabold text-white">
                6 Hub Utama + Plaza
              </span>
            </div>
          </div>

          <div className="text-xs text-[#A49BE1] font-medium">
            Pilih peran (Role) di samping untuk langsung menguji seluruh alur
            terintegrasi.
          </div>
        </div>

        {/* Panel Kanan: Form Login & Role Selector */}
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center bg-white">
          <h2 className="text-2xl font-black text-[#352C74]">
            Masuk ke KOPERAVERSE
          </h2>
          <p className="text-sm text-gray-500 mt-1">
            Pilih role simulasi untuk mengakses fitur dan kota virtual sesuai
            hak akses.
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            <div className="grid grid-cols-1 gap-3">
              {rolePresets.map((preset) => {
                const Icon = preset.icon;
                const isSelected = selectedRole === preset.id;
                return (
                  <button
                    type="button"
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-4 rounded-2xl border-2 text-left transition flex items-start gap-3.5 ${
                      isSelected
                        ? 'border-[#352C74] bg-[#D1EBEF]/45 shadow-md'
                        : 'border-gray-200 hover:border-[#A49BE1] bg-white'
                    }`}
                  >
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 text-white"
                      style={{
                        backgroundColor: isSelected
                          ? COLORS.deepNavy
                          : COLORS.purple,
                      }}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-extrabold text-sm text-[#352C74]">
                          {preset.title}
                        </span>
                        <span
                          className="text-[10px] font-bold px-2.5 py-0.5 rounded-full"
                          style={{
                            backgroundColor: isSelected
                              ? COLORS.deepNavy
                              : COLORS.softCyan,
                            color: isSelected ? COLORS.white : COLORS.deepNavy,
                          }}
                        >
                          {preset.badge}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        {preset.subtitle}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-bold text-[#352C74] mb-1">
                  Nama Tampilan
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-[#352C74] mb-1">
                  Email Akun
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl font-extrabold text-sm text-white shadow-lg hover:opacity-95 transition flex items-center justify-center gap-2"
              style={{ backgroundColor: COLORS.deepNavy }}
            >
              Masuk & Jelajahi Kota Virtual <ChevronRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// KOMPONEN HALAMAN NONANGGOTA (5 FITUR LENGKAP)
// ============================================================================
function NonanggotaViews({ activePage, navigateTo, switchRoleAndLogin }) {
  const { products, applicants, registerApplicant, showToast } =
    useContext(AppContext);
  const [searchProd, setSearchProd] = useState('');
  const [catFilter, setCatFilter] = useState('Semua');
  const [selectedProduct, setSelectedProduct] = useState(null);

  // State Edukasi Interaktif
  const [activeLesson, setActiveLesson] = useState(0);
  const [quizAnswer, setQuizAnswer] = useState(null);

  // State Form Pendaftaran Anggota
  const [regForm, setRegForm] = useState({
    name: '',
    nik: '',
    email: '',
    phone: '',
    unitUsaha: '',
    setoranAwal: 1000000,
  });
  const [submittedReg, setSubmittedReg] = useState(null);

  const lessons = [
    {
      title: '1. Apa Itu Koperasi Digital Modern?',
      content:
        'Koperasi adalah badan usaha yang beranggotakan orang-seorang atau badan hukum koperasi dengan melandaskan kegiatannya berdasarkan prinsip koperasi sekaligus sebagai gerakan ekonomi rakyat berdasar atas asas kekeluargaan. Di KOPERAVERSE, seluruh layanan simpan pinjam, pasar UMKM, hingga Rapat Anggota Tahunan (RAT) terdigitalisasi secara transparan.',
      keyPoint: 'Pemilik sekaligus pengguna layanan utama adalah Anggota.',
    },
    {
      title: '2. Manfaat Bergabung Sebagai Anggota',
      content:
        'Anggota berhak memperoleh Sisa Hasil Usaha (SHU) sesuai partisipasi modal dan transaksi, akses pembiayaan modal usaha berbunga rendah, etalase digital di Marketplace Koperaverse, serta pendampingan bisnis gratis di Cooperative Academy & Youth Hub.',
      keyPoint:
        'Semakin aktif bertransaksi, semakin besar pembagian SHU tahunan.',
    },
    {
      title: '3. Struktur Simpanan Pokok, Wajib & Sukarela',
      content:
        'Simpanan Pokok dibayarkan sekali saat mendaftar sebagai tanda kepemilikan. Simpanan Wajib dibayar rutin setiap bulan untuk memperkuat permodalan bersama. Simpanan Sukarela dapat disetor dan ditarik kapan saja layaknya tabungan digital.',
      keyPoint: 'Semua simpanan tercatat real-time dan dapat diaudit.',
    },
  ];

  const filteredProducts = products.filter((p) => {
    const matchSearch =
      p.name.toLowerCase().includes(searchProd.toLowerCase()) ||
      p.seller.toLowerCase().includes(searchProd.toLowerCase());
    const matchCat = catFilter === 'Semua' || p.category === catFilter;
    return matchSearch && matchCat;
  });

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    const newApp = registerApplicant(regForm);
    setSubmittedReg(newApp);
    setRegForm({
      name: '',
      nik: '',
      email: '',
      phone: '',
      unitUsaha: '',
      setoranAwal: 1000000,
    });
  };

  if (activePage === 'beranda') {
    return (
      <div className="space-y-6">
        {/* Hero Banner */}
        <div
          className="rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden"
          style={{
            background: `linear-gradient(120deg, ${COLORS.deepNavy}, ${COLORS.purple})`,
          }}
        >
          <div className="max-w-2xl relative z-10">
            <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-[#D1EBEF] text-[#352C74]">
              Selamat Datang Pengunjung
            </span>
            <h2 className="text-2xl sm:text-3xl font-black mt-3 leading-snug">
              Bangun Masa Depan Ekonomi Bersama di KOPERAVERSE
            </h2>
            <p className="text-sm text-[#D1EBEF] mt-2 leading-relaxed">
              Jelajahi kota virtual koperasi, pelajari sistem ekonomi
              kolaboratif, temukan produk UMKM berkualitas, dan daftarkan dirimu
              menjadi bagian dari ekosistem kami.
            </p>
            <div className="flex flex-wrap gap-3 mt-5">
              <button
                onClick={() => navigateTo('daftar')}
                className="px-5 py-2.5 rounded-xl bg-[#D1EBEF] text-[#352C74] font-extrabold text-sm hover:bg-white transition shadow-md flex items-center gap-2"
              >
                <UserCheck className="w-4 h-4" /> Daftar Jadi Anggota
              </button>
              <button
                onClick={() => navigateTo('katalog')}
                className="px-5 py-2.5 rounded-xl bg-white/15 border border-white/30 text-white font-bold text-sm hover:bg-white/25 transition flex items-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" /> Lihat Katalog Produk
              </button>
            </div>
          </div>
        </div>

        {/* 4 Kartu Menu Cepat Nonanggota */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              id: 'info',
              title: 'Informasi Koperasi',
              desc: 'Visi, misi, struktur organisasi & statistik aset transparan.',
              icon: Building2,
              color: COLORS.deepNavy,
            },
            {
              id: 'katalog',
              title: 'Katalog Produk UMKM',
              desc: 'Eksplorasi puluhan produk unggulan karya anggota koperasi.',
              icon: ShoppingBag,
              color: COLORS.purple,
            },
            {
              id: 'edukasi',
              title: 'Edukasi Perkoperasian',
              desc: 'Modul interaktif & kuis pemahaman prinsip koperasi.',
              icon: BookOpen,
              color: COLORS.lavender,
            },
            {
              id: 'daftar',
              title: 'Formulir Pendaftaran',
              desc: 'Ajukan keanggotaan online & langsung masuk antrean verifikasi.',
              icon: UserCheck,
              color: COLORS.deepNavy,
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                className="bg-white p-5 rounded-2xl shadow-md border border-[#A49BE1]/30 hover:border-[#352C74] hover:-translate-y-1 transition text-left flex flex-col justify-between"
              >
                <div>
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-white mb-3"
                    style={{ backgroundColor: item.color }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-base text-[#352C74]">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
                <span className="mt-4 text-xs font-bold text-[#9784CE] flex items-center gap-1">
                  Buka Fitur <ChevronRight className="w-4 h-4" />
                </span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  if (activePage === 'info') {
    return (
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-[#A49BE1]/30 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-100 pb-4">
          <div>
            <span className="text-xs font-extrabold uppercase tracking-wider text-[#9784CE]">
              Profil Lembaga
            </span>
            <h2 className="text-2xl font-black text-[#352C74]">
              Informasi Koperasi Digital KOPERAVERSE
            </h2>
          </div>
          <button
            onClick={() => navigateTo('daftar')}
            className="px-4 py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
          >
            Gabung Sekarang
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 rounded-2xl bg-[#D1EBEF]/50 border border-[#A49BE1]/40">
            <h3 className="font-extrabold text-[#352C74] text-lg">
              Visi & Misi
            </h3>
            <p className="text-sm text-gray-700 mt-2 leading-relaxed">
              <strong>Visi:</strong> Menjadi ekosistem koperasi digital terdepan
              yang memberdayakan UMKM dan generasi muda melalui teknologi
              transparan dan inklusif.
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-gray-700 list-disc list-inside">
              <li>Menyediakan akses permodalan adil dan berbunga rendah.</li>
              <li>
                Memperluas pasar produk anggota melalui marketplace
                terintegrasi.
              </li>
              <li>
                Meningkatkan literasi digital dan kewirausahaan berkelanjutan.
              </li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-[#A49BE1]/15 border border-[#A49BE1]/40 space-y-3">
            <h3 className="font-extrabold text-[#352C74] text-lg">
              Keunggulan & Tata Kelola
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white p-3 rounded-xl shadow-sm">
                <span className="text-xs text-gray-500">Badan Hukum</span>
                <p className="font-extrabold text-sm text-[#352C74]">
                  AHU-004821.AH.01.26
                </p>
              </div>
              <div className="bg-white p-3 rounded-xl shadow-sm">
                <span className="text-xs text-gray-500">Jasa Simpanan</span>
                <p className="font-extrabold text-sm text-[#352C74]">
                  Hingga 6.5% / Tahun
                </p>
              </div>
              <div className="bg-white p-3 rounded-xl shadow-sm">
                <span className="text-xs text-gray-500">Bunga Pinjaman</span>
                <p className="font-extrabold text-sm text-[#352C74]">
                  0.7% Flat / Bulan
                </p>
              </div>
              <div className="bg-white p-3 rounded-xl shadow-sm">
                <span className="text-xs text-gray-500">Audit Keuangan</span>
                <p className="font-extrabold text-sm text-[#352C74]">
                  Real-Time & RAT
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (activePage === 'katalog') {
    return (
      <div className="space-y-5">
        <div className="bg-white p-5 rounded-3xl shadow-md border border-[#A49BE1]/30 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari produk atau nama UMKM..."
              value={searchProd}
              onChange={(e) => setSearchProd(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div className="flex flex-wrap gap-2 w-full sm:w-auto">
            {[
              'Semua',
              'Kuliner & Minuman',
              'Kriya & Fashion',
              'Pertanian & Pangan',
              'Jasa & Digital',
            ].map((cat) => (
              <button
                key={cat}
                onClick={() => setCatFilter(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  catFilter === cat
                    ? 'bg-[#352C74] text-white'
                    : 'bg-[#D1EBEF] text-[#352C74] hover:bg-[#A49BE1] hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-2xl p-5 shadow-md border border-[#A49BE1]/30 flex flex-col justify-between"
            >
              <div>
                <div
                  className="h-28 rounded-xl mb-3 flex items-center justify-center relative"
                  style={{ backgroundColor: p.color }}
                >
                  <Package className="w-12 h-12 text-white/90" />
                  <span className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-[#D1EBEF] text-[#352C74]">
                    {p.badge}
                  </span>
                </div>
                <span className="text-[11px] font-bold text-[#9784CE]">
                  {p.category}
                </span>
                <h3 className="font-extrabold text-base text-[#352C74] mt-0.5">
                  {p.name}
                </h3>
                <p className="text-xs text-gray-500 mt-1">
                  Oleh: {p.seller} • Stok: {p.stock}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                <span className="font-black text-base text-[#352C74]">
                  {formatRupiah(p.price)}
                </span>
                <button
                  onClick={() => setSelectedProduct(p)}
                  className="px-3.5 py-1.5 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
                >
                  Detail Produk
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Detail Produk */}
        {selectedProduct && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border-2 border-[#9784CE]">
              <div className="flex justify-between items-start">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#D1EBEF] text-[#352C74]">
                  {selectedProduct.category}
                </span>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1 rounded-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5 text-[#352C74]" />
                </button>
              </div>
              <h3 className="text-xl font-black text-[#352C74] mt-3">
                {selectedProduct.name}
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                Produsen UMKM: <strong>{selectedProduct.seller}</strong>
              </p>
              <p className="text-sm text-gray-700 mt-3 leading-relaxed">
                {selectedProduct.desc}
              </p>
              <div className="mt-4 p-3 rounded-xl bg-[#D1EBEF]/50 flex items-center justify-between">
                <span className="text-xs font-bold text-[#352C74]">
                  Harga Anggota & Umum
                </span>
                <span className="text-lg font-black text-[#352C74]">
                  {formatRupiah(selectedProduct.price)}
                </span>
              </div>
              <div className="mt-5 flex gap-2">
                <button
                  onClick={() => {
                    setSelectedProduct(null);
                    navigateTo('daftar');
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-[#352C74] text-white text-xs font-extrabold hover:bg-[#9784CE] transition"
                >
                  Daftar Anggota untuk Belanja & Dapat SHU
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (activePage === 'edukasi') {
    return (
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-[#A49BE1]/30 space-y-6">
        <div>
          <span className="text-xs font-extrabold uppercase text-[#9784CE]">
            Literasi Dasar
          </span>
          <h2 className="text-2xl font-black text-[#352C74]">
            Edukasi Perkoperasian Interaktif
          </h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {lessons.map((l, idx) => (
            <button
              key={idx}
              onClick={() => setActiveLesson(idx)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeLesson === idx
                  ? 'bg-[#352C74] text-white'
                  : 'bg-[#D1EBEF] text-[#352C74]'
              }`}
            >
              Modul {idx + 1}
            </button>
          ))}
        </div>

        <div className="p-6 rounded-2xl bg-[#D1EBEF]/45 border border-[#A49BE1]/40">
          <h3 className="text-lg font-extrabold text-[#352C74]">
            {lessons[activeLesson].title}
          </h3>
          <p className="text-sm text-gray-700 mt-3 leading-relaxed">
            {lessons[activeLesson].content}
          </p>
          <div className="mt-4 p-3 rounded-xl bg-white border-l-4 border-[#352C74] text-xs font-bold text-[#352C74]">
            Intisari: {lessons[activeLesson].keyPoint}
          </div>
        </div>

        {/* Mini Kuis Pemahaman */}
        <div className="p-5 rounded-2xl border border-gray-200 space-y-3">
          <h4 className="font-extrabold text-sm text-[#352C74]">
            Kuis Cepat: Siapakah pemegang kekuasaan tertinggi dalam koperasi?
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'a', label: 'A. Rapat Anggota Tahunan (RAT)' },
              { id: 'b', label: 'B. Pemilik Modal Terbesar' },
              { id: 'c', label: 'C. Manajer Operasional' },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => {
                  setQuizAnswer(opt.id);
                  if (opt.id === 'a')
                    showToast(
                      'Benar! Rapat Anggota (RAT) adalah pemegang kekuasaan tertinggi.'
                    );
                }}
                className={`p-3 rounded-xl text-xs font-bold border text-left transition ${
                  quizAnswer === opt.id
                    ? opt.id === 'a'
                      ? 'bg-emerald-100 border-emerald-600 text-emerald-900'
                      : 'bg-rose-100 border-rose-600 text-rose-900'
                    : 'bg-white border-gray-200 hover:border-[#9784CE] text-[#352C74]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Halaman Formulir Pendaftaran Anggota
  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-[#A49BE1]/30 max-w-3xl mx-auto">
      <div className="border-b border-gray-100 pb-4 mb-6">
        <span className="text-xs font-extrabold uppercase text-[#9784CE]">
          Keanggotaan Baru
        </span>
        <h2 className="text-2xl font-black text-[#352C74]">
          Formulir Pendaftaran Anggota KOPERAVERSE
        </h2>
        <p className="text-xs text-gray-500 mt-1">
          Data pendaftaran akan langsung masuk ke sistem verifikasi{' '}
          <strong>Pengurus Koperasi</strong>.
        </p>
      </div>

      {submittedReg && (
        <div className="mb-6 p-5 rounded-2xl bg-[#D1EBEF] border-2 border-[#352C74] space-y-3">
          <div className="flex items-center gap-2 text-[#352C74] font-extrabold">
            <CheckCircle2 className="w-5 h-5" /> Pengajuan Berhasil Dikirim! (
            {submittedReg.id})
          </div>
          <p className="text-xs text-[#352C74]">
            Terima kasih <strong>{submittedReg.name}</strong>. Permohonan Anda
            kini berada di antrean verifikasi Pengurus. Anda dapat mengeceknya
            langsung dengan berpindah ke role <strong>Pengurus</strong> atau
            mencoba simulasi mode <strong>Anggota</strong>.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() =>
                switchRoleAndLogin('pengurus', 'Dewan Pengurus Utama')
              }
              className="px-4 py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
            >
              Cek Antrean di Role Pengurus →
            </button>
            <button
              onClick={() => switchRoleAndLogin('anggota', submittedReg.name)}
              className="px-4 py-2 rounded-xl bg-white text-[#352C74] border border-[#352C74] text-xs font-bold hover:bg-gray-50 transition"
            >
              Simulasi Masuk Sebagai Anggota
            </button>
          </div>
        </div>
      )}

      <form onSubmit={handleRegisterSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Nama Lengkap Sesuai KTP *
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: Dimas Saputra"
              value={regForm.name}
              onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Nomor Induk Kependudukan (NIK) *
            </label>
            <input
              type="text"
              required
              placeholder="16 digit NIK"
              value={regForm.nik}
              onChange={(e) => setRegForm({ ...regForm, nik: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Email Aktif *
            </label>
            <input
              type="email"
              required
              placeholder="nama@email.com"
              value={regForm.email}
              onChange={(e) =>
                setRegForm({ ...regForm, email: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Nomor WhatsApp *
            </label>
            <input
              type="text"
              required
              placeholder="08xx-xxxx-xxxx"
              value={regForm.phone}
              onChange={(e) =>
                setRegForm({ ...regForm, phone: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Bidang Usaha / Profesi *
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: Kuliner, Kriya, Jasa Digital"
              value={regForm.unitUsaha}
              onChange={(e) =>
                setRegForm({ ...regForm, unitUsaha: e.target.value })
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-[#352C74] mb-1">
              Setoran Awal (Pokok + Sukarela)
            </label>
            <select
              value={regForm.setoranAwal}
              onChange={(e) =>
                setRegForm({ ...regForm, setoranAwal: Number(e.target.value) })
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:border-[#352C74]"
            >
              <option value={1000000}>Rp 1.000.000 (Simpanan Pokok)</option>
              <option value={1500000}>
                Rp 1.500.000 (Pokok + Sukarela Rp 500rb)
              </option>
              <option value={2500000}>
                Rp 2.500.000 (Pokok + Sukarela Rp 1.5jt)
              </option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3.5 rounded-2xl bg-[#352C74] text-white font-extrabold text-sm hover:bg-[#9784CE] transition shadow-lg"
        >
          Kirim Formulir Pendaftaran Anggota
        </button>
      </form>
    </div>
  );
}

// ============================================================================
// KOMPONEN HALAMAN ANGGOTA (10 FITUR LENGKAP TERINTEGRASI)
// ============================================================================
function AnggotaViews({ activePage, navigateTo, open3DWithTeleport }) {
  const {
    currentMember,
    updateAvatar,
    addSavingDeposit,
    requestLoan,
    transactions,
    products,
    addProduct,
    checkoutCart,
    courses,
    enrollOrAdvanceCourse,
    polls,
    castVote,
    posts,
    addPost,
    toggleLikePost,
    addCommentPost,
    mentors,
    bookMentorSlot,
    addAuditLog,
    showToast,
  } = useContext(AppContext);

  // Local states untuk form & interaksi tiap sub-halaman
  const [depositAmount, setDepositAmount] = useState(500000);
  const [loanAmount, setLoanAmount] = useState(3000000);
  const [loanTenor, setLoanTenor] = useState(12);
  const [loanPurpose, setLoanPurpose] = useState(
    'Ekspansi Peralatan Produksi UMKM'
  );

  // Marketplace states
  const [cart, setCart] = useState([]);
  const [marketSearch, setMarketSearch] = useState('');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProd, setNewProd] = useState({
    name: '',
    category: 'Kuliner & Minuman',
    price: 50000,
    stock: 20,
    desc: '',
  });

  // Community & Youth Hub states
  const [newPostText, setNewPostText] = useState('');
  const [newPostGroup, setNewPostGroup] = useState('Kriya & Ekspor');
  const [commentInputs, setCommentInputs] = useState({});
  const [pitchIdea, setPitchIdea] = useState({
    title: '',
    problem: '',
    funding: 10000000,
  });

  // Help Center states
  const [chatMessages, setChatMessages] = useState([
    {
      sender: 'bot',
      text: 'Halo! Saya Asisten Virtual KOPERAVERSE. Ada yang bisa dibantu terkait simpan pinjam, SHU, atau kota 3D?',
    },
  ]);
  const [chatInput, setChatInput] = useState('');

  // 1. DASHBOARD ANGGOTA
  if (activePage === 'dashboard') {
    const totalSimpanan =
      currentMember.simpananPokok +
      currentMember.simpananWajib +
      currentMember.simpananSukarela;
    const estimasiSHU = Math.round(
      totalSimpanan * 0.085 + currentMember.poinAktivitas * 450
    );

    const shortcuts = [
      { id: 'avatar', label: 'Avatar 3D', icon: User, color: COLORS.purple },
      {
        id: 'my-coop',
        label: 'My Cooperative',
        icon: Building2,
        color: COLORS.deepNavy,
      },
      {
        id: 'financial',
        label: 'Financial Center',
        icon: Wallet,
        color: COLORS.purple,
      },
      {
        id: 'marketplace',
        label: 'Marketplace',
        icon: ShoppingBag,
        color: COLORS.lavender,
      },
      {
        id: 'academy',
        label: 'Academy',
        icon: GraduationCap,
        color: COLORS.deepNavy,
      },
      {
        id: 'assembly',
        label: 'Assembly Hall',
        icon: Vote,
        color: COLORS.purple,
      },
      {
        id: 'community',
        label: 'Community Hub',
        icon: MessageSquare,
        color: COLORS.lavender,
      },
      { id: 'youth', label: 'Youth Hub', icon: Rocket, color: COLORS.deepNavy },
      {
        id: 'help',
        label: 'Help Center',
        icon: HelpCircle,
        color: COLORS.purple,
      },
    ];

    return (
      <div className="space-y-6">
        {/* Ringkasan Saldo & KPI Anggota */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            className="p-5 rounded-2xl text-white shadow-lg"
            style={{ backgroundColor: COLORS.deepNavy }}
          >
            <span className="text-xs text-[#D1EBEF] font-semibold">
              Total Simpanan Anda
            </span>
            <p className="text-2xl font-black mt-1">
              {formatRupiah(totalSimpanan)}
            </p>
            <span className="inline-block mt-2 text-[11px] px-2 py-0.5 rounded-full bg-white/15">
              Sukarela: {formatRupiah(currentMember.simpananSukarela)}
            </span>
          </div>
          <div
            className="p-5 rounded-2xl text-white shadow-lg"
            style={{ backgroundColor: COLORS.purple }}
          >
            <span className="text-xs text-white/90 font-semibold">
              Estimasi SHU Tahun Ini
            </span>
            <p className="text-2xl font-black mt-1">
              {formatRupiah(estimasiSHU)}
            </p>
            <span className="inline-block mt-2 text-[11px] px-2 py-0.5 rounded-full bg-white/20">
              Proyeksi Naik +14%
            </span>
          </div>
          <div className="p-5 rounded-2xl bg-white shadow-md border border-[#A49BE1]/40">
            <span className="text-xs text-gray-500 font-semibold">
              Pinjaman Aktif
            </span>
            <p className="text-2xl font-black text-[#352C74] mt-1">
              {formatRupiah(currentMember.pinjamanAktif)}
            </p>
            <span className="inline-block mt-2 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
              Kolektibilitas Lancar
            </span>
          </div>
          <div className="p-5 rounded-2xl bg-white shadow-md border border-[#A49BE1]/40">
            <span className="text-xs text-gray-500 font-semibold">
              Poin Aktivitas & Metaverse
            </span>
            <p className="text-2xl font-black text-[#352C74] mt-1">
              {currentMember.poinAktivitas} PTS
            </p>
            <span className="inline-block mt-2 text-[11px] font-bold text-[#352C74] bg-[#D1EBEF] px-2 py-0.5 rounded-full">
              Badge: {currentMember.avatar.title}
            </span>
          </div>
        </div>

        {/* Grid Akses Cepat ke Semua 10 Fitur Anggota */}
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-black text-lg text-[#352C74]">
              Ekosistem Layanan Anggota
            </h3>
            <button
              onClick={() => open3DWithTeleport('my-coop')}
              className="px-3.5 py-1.5 rounded-xl bg-[#D1EBEF] text-[#352C74] text-xs font-extrabold hover:bg-[#A49BE1] hover:text-white transition flex items-center gap-1.5"
            >
              <Gamepad2 className="w-4 h-4" /> Jelajahi di Kota 3D
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {shortcuts.map((sc) => {
              const Icon = sc.icon;
              return (
                <button
                  key={sc.id}
                  onClick={() => navigateTo(sc.id)}
                  className="p-4 rounded-2xl border border-gray-100 bg-[#D1EBEF]/25 hover:bg-[#D1EBEF]/70 hover:border-[#352C74] transition flex flex-col items-center text-center gap-2"
                >
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shadow"
                    style={{ backgroundColor: sc.color }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="font-extrabold text-xs text-[#352C74]">
                    {sc.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // 2. AVATAR CUSTOMIZER (REAL-TIME KE DUNIA 3D)
  if (activePage === 'avatar') {
    const av = currentMember.avatar;
    const outfitColors = [
      { label: 'Deep Navy', hex: '#352C74' },
      { label: 'Royal Purple', hex: '#9784CE' },
      { label: 'Soft Lavender', hex: '#A49BE1' },
      { label: 'Cyan Mint', hex: '#4DB6AC' },
    ];
    const skinColors = ['#F5CBA7', '#E0AC69', '#D2996C', '#8D5524'];

    return (
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-lg border border-[#A49BE1]/30 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Preview Avatar 2D Stylised + Tombol ke 3D */}
        <div
          className="lg:col-span-5 rounded-3xl p-6 flex flex-col items-center justify-between text-center"
          style={{ backgroundColor: COLORS.softCyan }}
        >
          <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-[#352C74] text-white">
            Live Avatar Preview
          </span>

          {/* Karakter Blocky SVG */}
          <div className="my-6 relative">
            <svg width="170" height="220" viewBox="0 0 170 220">
              {av.hat === 'crown' && (
                <polygon
                  points="55,24 65,6 85,20 105,6 115,24"
                  fill="#FFD54F"
                  stroke="#352C74"
                  strokeWidth="3"
                />
              )}
              <rect
                x="52"
                y="24"
                width="66"
                height="54"
                rx="10"
                fill={av.skin}
                stroke="#352C74"
                strokeWidth="3"
              />
              <rect
                x="52"
                y="20"
                width="66"
                height="16"
                rx="6"
                fill={av.hair}
              />
              <circle cx="72" cy="48" r="4" fill="#1A1A1A" />
              <circle cx="98" cy="48" r="4" fill="#1A1A1A" />
              <path
                d="M 74 61 Q 85 69 96 61"
                stroke="#1A1A1A"
                strokeWidth="3"
                fill="none"
                strokeLinecap="round"
              />
              {av.hat === 'visor' && (
                <rect
                  x="50"
                  y="40"
                  width="70"
                  height="14"
                  rx="5"
                  fill="#D1EBEF"
                  fillOpacity="0.85"
                  stroke="#352C74"
                  strokeWidth="2.5"
                />
              )}
              {/* Badan & Lengan */}
              <rect
                x="24"
                y="84"
                width="22"
                height="58"
                rx="8"
                fill={av.skin}
                stroke="#352C74"
                strokeWidth="3"
              />
              <rect
                x="124"
                y="84"
                width="22"
                height="58"
                rx="8"
                fill={av.skin}
                stroke="#352C74"
                strokeWidth="3"
              />
              <rect
                x="48"
                y="82"
                width="74"
                height="68"
                rx="10"
                fill={av.shirt}
                stroke="#352C74"
                strokeWidth="3"
              />
              {/* Kaki */}
              <rect
                x="52"
                y="152"
                width="30"
                height="56"
                rx="8"
                fill={av.pants}
                stroke="#352C74"
                strokeWidth="3"
              />
              <rect
                x="88"
                y="152"
                width="30"
                height="56"
                rx="8"
                fill={av.pants}
                stroke="#352C74"
                strokeWidth="3"
              />
            </svg>
            <div className="mt-2 font-black text-base text-[#352C74]">
              {currentMember.name}
            </div>
            <div className="text-xs font-bold text-[#9784CE]">{av.title}</div>
          </div>

          <button
            onClick={() => open3DWithTeleport('my-coop')}
            className="w-full py-3 rounded-2xl bg-[#352C74] text-white font-extrabold text-xs hover:bg-[#9784CE] transition shadow-md flex items-center justify-center gap-2"
          >
            <Gamepad2 className="w-4 h-4" /> Lihat Avatar di Kota 3D Sekarang
          </button>
        </div>

        {/* Panel Kustomisasi */}
        <div className="lg:col-span-7 space-y-5">
          <div>
            <h2 className="text-2xl font-black text-[#352C74]">
              Kustomisasi Avatar Metaverse
            </h2>
            <p className="text-xs text-gray-500">
              Perubahan tampilan langsung diterapkan pada karakter 3D Anda di
              kota virtual.
            </p>
          </div>

          <div>
            <label className="block text-xs font-extrabold text-[#352C74] mb-2">
              Warna Kulit Avatar
            </label>
            <div className="flex gap-3">
              {skinColors.map((hex) => (
                <button
                  key={hex}
                  onClick={() => updateAvatar({ skin: hex })}
                  className={`w-10 h-10 rounded-full border-4 transition ${
                    av.skin === hex
                      ? 'border-[#352C74] scale-110'
                      : 'border-white shadow'
                  }`}
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-extrabold text-[#352C74] mb-2">
              Seragam & Outfit Koperasi
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {outfitColors.map((c) => (
                <button
                  key={c.hex}
                  onClick={() => updateAvatar({ shirt: c.hex })}
                  className={`p-3 rounded-xl border-2 text-xs font-bold flex items-center gap-2 ${
                    av.shirt === c.hex
                      ? 'border-[#352C74] bg-[#D1EBEF]/40'
                      : 'border-gray-200'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full shrink-0"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span className="truncate text-[#352C74]">{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-extrabold text-[#352C74] mb-2">
              Aksesori Kepala
            </label>
            <div className="flex flex-wrap gap-2.5">
              {[
                { id: 'none', label: 'Tanpa Aksesori' },
                { id: 'crown', label: 'Mahkota Wirausaha' },
                { id: 'visor', label: 'Cyber Visor Cyan' },
              ].map((h) => (
                <button
                  key={h.id}
                  onClick={() => updateAvatar({ hat: h.id })}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border transition ${
                    av.hat === h.id
                      ? 'bg-[#352C74] text-white border-[#352C74]'
                      : 'bg-white text-[#352C74] border-gray-200'
                  }`}
                >
                  {h.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-extrabold text-[#352C74] mb-2">
              Gelar / Title Anggota
            </label>
            <select
              value={av.title}
              onChange={(e) => updateAvatar({ title: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-semibold text-[#352C74]"
            >
              <option value="Wirausaha Muda">Wirausaha Muda</option>
              <option value="Inovator UMKM">Inovator UMKM</option>
              <option value="Pelopor Gotong Royong">
                Pelopor Gotong Royong
              </option>
              <option value="Investor Koperasi">Investor Koperasi</option>
            </select>
          </div>
        </div>
      </div>
    );
  }

  // 3. MY COOPERATIVE (KARTU ANGGOTA DIGITAL & SIMPANAN)
  if (activePage === 'my-coop') {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Kartu Digital Anggota */}
          <div
            className="lg:col-span-5 rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between"
            style={{
              background: `linear-gradient(135deg, ${COLORS.deepNavy}, ${COLORS.purple})`,
            }}
          >
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#D1EBEF] font-bold">
                  Kartu Anggota Digital
                </span>
                <h3 className="text-xl font-black mt-0.5">KOPERAVERSE</h3>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-[#D1EBEF] text-[#352C74]">
                {currentMember.status}
              </span>
            </div>

            <div className="my-6">
              <p className="text-xs text-[#D1EBEF]">Nomor Induk Anggota</p>
              <p className="text-lg font-mono font-bold tracking-wider">
                {currentMember.id}
              </p>
              <p className="text-lg font-extrabold mt-2">
                {currentMember.name}
              </p>
              <p className="text-xs text-white/80">
                Unit Usaha: {currentMember.unitUsaha}
              </p>
            </div>

            <div className="flex justify-between items-center text-xs border-t border-white/20 pt-3">
              <span>Bergabung: {currentMember.joinDate}</span>
              <span className="font-bold text-[#D1EBEF]">Terverifikasi</span>
            </div>
          </div>

          {/* Rincian Simpanan & Top Up Cepat */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 shadow-md border border-[#A49BE1]/30 space-y-4">
            <h3 className="font-black text-lg text-[#352C74]">
              Rincian Simpanan Keanggotaan
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-[#D1EBEF]/45">
                <span className="text-xs text-gray-600 font-semibold">
                  Simpanan Pokok
                </span>
                <p className="font-black text-base text-[#352C74] mt-1">
                  {formatRupiah(currentMember.simpananPokok)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-[#A49BE1]/20">
                <span className="text-xs text-gray-600 font-semibold">
                  Simpanan Wajib
                </span>
                <p className="font-black text-base text-[#352C74] mt-1">
                  {formatRupiah(currentMember.simpananWajib)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-[#9784CE]/20">
                <span className="text-xs text-gray-600 font-semibold">
                  Simpanan Sukarela
                </span>
                <p className="font-black text-base text-[#352C74] mt-1">
                  {formatRupiah(currentMember.simpananSukarela)}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-gray-100">
              <label className="block text-xs font-extrabold text-[#352C74] mb-2">
                Setor Simpanan Sukarela Instan
              </label>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <select
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-gray-300 text-sm font-bold text-[#352C74]"
                >
                  <option value={250000}>Rp 250.000</option>
                  <option value={500000}>Rp 500.000</option>
                  <option value={1000000}>Rp 1.000.000</option>
                  <option value={2500000}>Rp 2.500.000</option>
                </select>
                <button
                  onClick={() => addSavingDeposit(depositAmount)}
                  className="px-5 py-2.5 rounded-xl bg-[#352C74] text-white font-extrabold text-xs hover:bg-[#9784CE] transition"
                >
                  + Setor Sekarang
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 4. FINANCIAL CENTER (SIMULASI & PENGAJUAN PINJAMAN)
  if (activePage === 'financial') {
    const monthlyInterest = 0.007; // 0.7% flat
    const monthlyInstallment = Math.round(
      loanAmount / loanTenor + loanAmount * monthlyInterest
    );

    const handleLoanSubmit = (e) => {
      e.preventDefault();
      requestLoan({
        amount: loanAmount,
        tenor: loanTenor,
        purpose: loanPurpose,
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Kalkulator & Form Pinjaman */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 shadow-md border border-[#A49BE1]/30">
            <h3 className="font-black text-lg text-[#352C74]">
              Simulasi & Pengajuan Pinjaman Produktif
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Jasa pinjaman ringan 0.7% flat per bulan khusus anggota aktif.
            </p>

            <form onSubmit={handleLoanSubmit} className="mt-4 space-y-4">
              <div>
                <div className="flex justify-between text-xs font-bold text-[#352C74] mb-1">
                  <span>Plafon Pinjaman</span>
                  <span>{formatRupiah(loanAmount)}</span>
                </div>
                <input
                  type="range"
                  min={1000000}
                  max={25000000}
                  step={500000}
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Number(e.target.value))}
                  className="w-full accent-[#352C74]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#352C74] mb-1">
                  Tenor Angsuran
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[6, 12, 18, 24].map((t) => (
                    <button
                      type="button"
                      key={t}
                      onClick={() => setLoanTenor(t)}
                      className={`py-2 rounded-xl text-xs font-bold border ${
                        loanTenor === t
                          ? 'bg-[#352C74] text-white border-[#352C74]'
                          : 'bg-white text-[#352C74] border-gray-200'
                      }`}
                    >
                      {t} Bulan
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#352C74] mb-1">
                  Tujuan Penggunaan Dana
                </label>
                <input
                  type="text"
                  required
                  value={loanPurpose}
                  onChange={(e) => setLoanPurpose(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-sm"
                />
              </div>

              <div className="p-4 rounded-2xl bg-[#D1EBEF]/60 flex items-center justify-between">
                <div>
                  <span className="text-xs text-[#352C74] font-semibold">
                    Estimasi Cicilan / Bulan
                  </span>
                  <p className="text-xl font-black text-[#352C74]">
                    {formatRupiah(monthlyInstallment)}
                  </p>
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#352C74] text-white font-extrabold text-xs hover:bg-[#9784CE] transition shadow"
                >
                  Ajukan Pinjaman
                </button>
              </div>
            </form>
          </div>

          {/* Riwayat Transaksi Keuangan */}
          <div className="lg:col-span-6 bg-white rounded-3xl p-6 shadow-md border border-[#A49BE1]/30">
            <h3 className="font-black text-lg text-[#352C74] mb-3">
              Mutasi & Status Pengajuan
            </h3>
            <div className="space-y-2.5 max-h-80 overflow-y-auto">
              {transactions.map((trx) => (
                <div
                  key={trx.id}
                  className="p-3.5 rounded-2xl border border-gray-100 bg-gray-50/70 flex items-center justify-between gap-2"
                >
                  <div>
                    <p className="font-extrabold text-xs text-[#352C74]">
                      {trx.type}
                    </p>
                    <p className="text-[11px] text-gray-500">
                      {trx.member} • {trx.date}
                    </p>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-black text-xs ${
                        trx.amount >= 0 ? 'text-emerald-700' : 'text-[#352C74]'
                      }`}
                    >
                      {trx.amount >= 0
                        ? `+${formatRupiah(trx.amount)}`
                        : formatRupiah(trx.amount)}
                    </p>
                    <span
                      className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        trx.status === 'Selesai' || trx.status === 'Disetujui'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {trx.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 5. MARKETPLACE ANGGOTA (BELI DENGAN SALDO SIMPANAN + JUAL PRODUK BARU)
  if (activePage === 'marketplace') {
    const cartTotal = cart.reduce(
      (sum, item) => sum + item.price * item.qty,
      0
    );

    const handleAddToCart = (prod) => {
      setCart((prev) => {
        const exists = prev.find((i) => i.id === prod.id);
        if (exists)
          return prev.map((i) =>
            i.id === prod.id ? { ...i, qty: i.qty + 1 } : i
          );
        return [...prev, { ...prod, qty: 1 }];
      });
      showToast(`${prod.name} ditambahkan ke keranjang!`);
    };

    const handleCheckout = () => {
      if (cartTotal === 0) return;
      if (checkoutCart(cartTotal, cart.map((c) => c.name).join(', '))) {
        setCart([]);
      }
    };

    const handleCreateProduct = (e) => {
      e.preventDefault();
      addProduct(newProd);
      setNewProd({
        name: '',
        category: 'Kuliner & Minuman',
        price: 50000,
        stock: 20,
        desc: '',
      });
      setShowAddProduct(false);
    };

    return (
      <div className="space-y-5">
        {/* Bar Atas Marketplace */}
        <div className="bg-white p-4 rounded-3xl shadow-md border border-[#A49BE1]/30 flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari produk UMKM anggota..."
              value={marketSearch}
              onChange={(e) => setMarketSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 text-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddProduct(!showAddProduct)}
              className="px-4 py-2 rounded-xl bg-[#9784CE] text-white text-xs font-extrabold hover:bg-[#352C74] transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Jual Produk Saya
            </button>
            <div className="px-3.5 py-2 rounded-xl bg-[#D1EBEF] text-[#352C74] text-xs font-extrabold">
              Saldo Sukarela: {formatRupiah(currentMember.simpananSukarela)}
            </div>
          </div>
        </div>

        {/* Form Tambah Produk UMKM */}
        {showAddProduct && (
          <form
            onSubmit={handleCreateProduct}
            className="bg-white p-5 rounded-3xl shadow-md border-2 border-[#9784CE] space-y-3"
          >
            <h4 className="font-extrabold text-sm text-[#352C74]">
              Tambah Produk Baru ke Etalase Koperaverse
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <input
                type="text"
                required
                placeholder="Nama Produk"
                value={newProd.name}
                onChange={(e) =>
                  setNewProd({ ...newProd, name: e.target.value })
                }
                className="px-3 py-2 rounded-xl border text-xs"
              />
              <select
                value={newProd.category}
                onChange={(e) =>
                  setNewProd({ ...newProd, category: e.target.value })
                }
                className="px-3 py-2 rounded-xl border text-xs"
              >
                <option>Kuliner & Minuman</option>
                <option>Kriya & Fashion</option>
                <option>Pertanian & Pangan</option>
                <option>Jasa & Digital</option>
              </select>
              <input
                type="number"
                required
                min={1000}
                placeholder="Harga (Rp)"
                value={newProd.price}
                onChange={(e) =>
                  setNewProd({ ...newProd, price: Number(e.target.value) })
                }
                className="px-3 py-2 rounded-xl border text-xs"
              />
              <button
                type="submit"
                className="py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold"
              >
                Publikasikan Produk
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Daftar Produk */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {products
              .filter((p) =>
                p.name.toLowerCase().includes(marketSearch.toLowerCase())
              )
              .map((p) => (
                <div
                  key={p.id}
                  className="bg-white p-4 rounded-2xl shadow border border-[#A49BE1]/30 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#D1EBEF] text-[#352C74]">
                        {p.category}
                      </span>
                      <span className="text-xs font-bold text-amber-500">
                        ★ {p.rating}
                      </span>
                    </div>
                    <h4 className="font-extrabold text-sm text-[#352C74]">
                      {p.name}
                    </h4>
                    <p className="text-[11px] text-gray-500 mt-0.5">
                      Penjual: {p.seller}
                    </p>
                    <p className="text-xs text-gray-600 mt-2 line-clamp-2">
                      {p.desc}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                    <span className="font-black text-sm text-[#352C74]">
                      {formatRupiah(p.price)}
                    </span>
                    <button
                      onClick={() => handleAddToCart(p)}
                      className="px-3 py-1.5 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
                    >
                      + Keranjang
                    </button>
                  </div>
                </div>
              ))}
          </div>

          {/* Keranjang Belanja & Checkout */}
          <div className="lg:col-span-4 bg-white p-5 rounded-3xl shadow-md border border-[#A49BE1]/30 h-fit">
            <h3 className="font-black text-base text-[#352C74] flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#9784CE]" /> Keranjang
              Belanja ({cart.reduce((s, i) => s + i.qty, 0)})
            </h3>
            {cart.length === 0 ? (
              <p className="text-xs text-gray-400 my-6 text-center">
                Belum ada produk di keranjang.
              </p>
            ) : (
              <div className="my-4 space-y-2.5">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="flex justify-between items-center text-xs border-b pb-2"
                  >
                    <div>
                      <p className="font-bold text-[#352C74]">{item.name}</p>
                      <p className="text-gray-500">
                        {item.qty} x {formatRupiah(item.price)}
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        setCart(cart.filter((c) => c.id !== item.id))
                      }
                      className="text-rose-600 font-bold"
                    >
                      Hapus
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="pt-3 border-t border-gray-100 space-y-3">
              <div className="flex justify-between font-black text-sm text-[#352C74]">
                <span>Total Bayar</span>
                <span>{formatRupiah(cartTotal)}</span>
              </div>
              <button
                disabled={cart.length === 0}
                onClick={handleCheckout}
                className="w-full py-3 rounded-xl bg-[#352C74] disabled:bg-gray-300 text-white font-extrabold text-xs hover:bg-[#9784CE] transition"
              >
                Bayar dengan Simpanan Sukarela
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 6. COOPERATIVE ACADEMY
  if (activePage === 'academy') {
    return (
      <div className="space-y-5">
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 flex flex-wrap justify-between items-center gap-4">
          <div>
            <h2 className="text-xl font-black text-[#352C74]">
              Cooperative Academy & Sertifikasi UMKM
            </h2>
            <p className="text-xs text-gray-500">
              Selesaikan pelatihan untuk menambah Poin Aktivitas & bobot
              pembagian SHU.
            </p>
          </div>
          <div className="px-4 py-2 rounded-2xl bg-[#D1EBEF] text-[#352C74] font-extrabold text-xs">
            Poin Terkumpul: {currentMember.poinAktivitas} PTS
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {courses.map((c) => (
            <div
              key={c.id}
              className="bg-white p-5 rounded-2xl shadow border border-[#A49BE1]/30 flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-center">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#A49BE1]/25 text-[#352C74]">
                    {c.category} • {c.level}
                  </span>
                  <span className="text-xs font-extrabold text-[#9784CE]">
                    +{c.points} PTS
                  </span>
                </div>
                <h3 className="font-extrabold text-base text-[#352C74] mt-2">
                  {c.title}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Mentor: {c.instructor} • Durasi: {c.duration}
                </p>

                <div className="mt-3 space-y-1">
                  {c.modules.map((m, i) => (
                    <div
                      key={i}
                      className="text-xs text-gray-600 flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#9784CE]" />{' '}
                      {m}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-gray-100">
                <div className="flex justify-between text-xs font-bold text-[#352C74] mb-1">
                  <span>Progres Belajar</span>
                  <span>{c.progress}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-gray-100 overflow-hidden mb-3">
                  <div
                    className="h-full bg-[#352C74] transition-all"
                    style={{ width: `${c.progress}%` }}
                  />
                </div>
                <button
                  onClick={() => enrollOrAdvanceCourse(c.id)}
                  className="w-full py-2.5 rounded-xl bg-[#352C74] text-white text-xs font-extrabold hover:bg-[#9784CE] transition"
                >
                  {!c.enrolled
                    ? 'Daftar Pelatihan Sekarang'
                    : c.progress < 100
                    ? 'Lanjutkan Modul (+40%)'
                    : 'Sertifikat Telah Terbit ✓'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 7. ASSEMBLY HALL (MUSYAWARAH & LIVE E-VOTING RAT)
  if (activePage === 'assembly') {
    return (
      <div className="space-y-6">
        <div
          className="rounded-3xl p-6 text-white shadow-lg"
          style={{ backgroundColor: COLORS.deepNavy }}
        >
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#D1EBEF] text-[#352C74]">
            Balai Musyawarah Digital (RAT)
          </span>
          <h2 className="text-2xl font-black mt-2">
            E-Voting & Pengambilan Keputusan Anggota
          </h2>
          <p className="text-xs text-[#D1EBEF] mt-1">
            Setiap anggota memiliki 1 hak suara sah (One Member One Vote). Hasil
            diperbarui secara real-time.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {polls.map((poll) => {
            const totalVotes = poll.options.reduce((s, o) => s + o.votes, 0);
            return (
              <div
                key={poll.id}
                className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-center text-xs text-gray-500 mb-2">
                    <span className="font-bold text-[#9784CE]">
                      Batas Voting: {poll.deadline}
                    </span>
                    <span>Total Suara: {totalVotes}</span>
                  </div>
                  <h3 className="font-extrabold text-base text-[#352C74]">
                    {poll.title}
                  </h3>
                  <p className="text-xs text-gray-600 mt-1.5 leading-relaxed">
                    {poll.desc}
                  </p>

                  <div className="mt-4 space-y-2.5">
                    {poll.options.map((opt) => {
                      const pct =
                        totalVotes > 0
                          ? Math.round((opt.votes / totalVotes) * 100)
                          : 0;
                      const isVoted = poll.votedOption === opt.id;
                      return (
                        <button
                          key={opt.id}
                          onClick={() => castVote(poll.id, opt.id)}
                          className={`w-full p-3 rounded-2xl border text-left transition relative overflow-hidden ${
                            isVoted
                              ? 'border-[#352C74] bg-[#D1EBEF]/45'
                              : 'border-gray-200 hover:border-[#9784CE]'
                          }`}
                        >
                          <div className="flex justify-between items-center text-xs font-bold text-[#352C74] relative z-10">
                            <span>
                              {opt.label} {isVoted && '(Pilihan Anda)'}
                            </span>
                            <span>
                              {pct}% ({opt.votes})
                            </span>
                          </div>
                          <div className="w-full h-1.5 bg-gray-100 rounded-full mt-2 overflow-hidden">
                            <div
                              className="h-full bg-[#352C74] transition-all"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 8. COMMUNITY HUB
  if (activePage === 'community') {
    const handlePost = (e) => {
      e.preventDefault();
      if (!newPostText.trim()) return;
      addPost(newPostText, newPostGroup);
      setNewPostText('');
    };

    return (
      <div className="max-w-3xl mx-auto space-y-5">
        <form
          onSubmit={handlePost}
          className="bg-white p-5 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-3"
        >
          <h3 className="font-black text-base text-[#352C74]">
            Forum Kolaborasi & Diskusi Anggota
          </h3>
          <textarea
            rows={2}
            placeholder="Bagikan perkembangan usaha, penawaran kolaborasi, atau pertanyaan ke sesama anggota..."
            value={newPostText}
            onChange={(e) => setNewPostText(e.target.value)}
            className="w-full p-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:border-[#352C74]"
          />
          <div className="flex flex-wrap justify-between items-center gap-2">
            <select
              value={newPostGroup}
              onChange={(e) => setNewPostGroup(e.target.value)}
              className="px-3 py-2 rounded-xl border text-xs font-bold text-[#352C74]"
            >
              <option>Kriya & Ekspor</option>
              <option>Agribisnis & Pangan</option>
              <option>Kuliner & Kafe</option>
              <option>Teknologi & Digital</option>
            </select>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#352C74] text-white text-xs font-extrabold hover:bg-[#9784CE] transition"
            >
              Kirim Postingan
            </button>
          </div>
        </form>

        <div className="space-y-4">
          {posts.map((post) => (
            <div
              key={post.id}
              className="bg-white p-5 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-3"
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-[#352C74]">
                      {post.author}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#D1EBEF] text-[#352C74]">
                      {post.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-gray-400">
                    {post.group} • {post.time}
                  </p>
                </div>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">
                {post.content}
              </p>
              <div className="flex items-center gap-4 pt-2 border-t border-gray-100">
                <button
                  onClick={() => toggleLikePost(post.id)}
                  className={`text-xs font-bold flex items-center gap-1 ${
                    post.liked ? 'text-[#9784CE]' : 'text-gray-500'
                  }`}
                >
                  ♥ Apresiasi ({post.likes})
                </button>
                <span className="text-xs text-gray-400">
                  {post.comments.length} Komentar
                </span>
              </div>

              {/* Komentar */}
              <div className="space-y-2 pl-3 border-l-2 border-[#D1EBEF]">
                {post.comments.map((c, idx) => (
                  <div key={idx} className="text-xs bg-gray-50 p-2 rounded-xl">
                    <strong className="text-[#352C74]">{c.author}:</strong>{' '}
                    {c.text}
                  </div>
                ))}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Tulis balasan..."
                    value={commentInputs[post.id] || ''}
                    onChange={(e) =>
                      setCommentInputs({
                        ...commentInputs,
                        [post.id]: e.target.value,
                      })
                    }
                    className="flex-1 px-3 py-1.5 rounded-xl border text-xs"
                  />
                  <button
                    onClick={() => {
                      if (!commentInputs[post.id]?.trim()) return;
                      addCommentPost(post.id, commentInputs[post.id]);
                      setCommentInputs({ ...commentInputs, [post.id]: '' });
                    }}
                    className="px-3 py-1.5 rounded-xl bg-[#352C74] text-white text-xs font-bold"
                  >
                    Kirim
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 9. YOUTH ENTREPRENEURSHIP HUB
  if (activePage === 'youth') {
    const handlePitchSubmit = (e) => {
      e.preventDefault();
      addAuditLog(
        'Youth Hub',
        `Submit Pitch Deck Usaha: ${pitchIdea.title} (${formatRupiah(
          pitchIdea.funding
        )})`
      );
      showToast(
        `Proposal inkubasi "${pitchIdea.title}" berhasil dikirim ke komite mentor!`
      );
      setPitchIdea({ title: '', problem: '', funding: 10000000 });
    };

    return (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Jadwal Mentoring 1-on-1 */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-4">
          <h3 className="font-black text-lg text-[#352C74]">
            Booking Mentoring 1-on-1 Wirausaha Muda
          </h3>
          <p className="text-xs text-gray-500">
            Pilih mentor praktisi untuk konsultasi strategi bisnis, teknologi,
            dan ekspor.
          </p>
          <div className="space-y-3">
            {mentors.map((m) => (
              <div
                key={m.id}
                className="p-4 rounded-2xl border border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <h4 className="font-extrabold text-sm text-[#352C74]">
                    {m.name}
                  </h4>
                  <p className="text-xs text-[#9784CE] font-semibold">
                    {m.role}
                  </p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {m.slots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => bookMentorSlot(m.id, slot)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        m.booked === slot
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#D1EBEF] text-[#352C74] hover:bg-[#352C74] hover:text-white'
                      }`}
                    >
                      {m.booked === slot ? `Terjadwal: ${slot}` : slot}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Form Pitch Deck Inkubator */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30">
          <h3 className="font-black text-lg text-[#352C74]">
            Ajukan Pitch Ide Usaha
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            Dapatkan pendanaan bergulir & bimbingan intensif selama 3 bulan.
          </p>
          <form onSubmit={handlePitchSubmit} className="mt-4 space-y-3">
            <div>
              <label className="block text-xs font-bold text-[#352C74] mb-1">
                Nama Startup / Inovasi Usaha
              </label>
              <input
                type="text"
                required
                placeholder="Contoh: EcoPack Kemasan Singkong"
                value={pitchIdea.title}
                onChange={(e) =>
                  setPitchIdea({ ...pitchIdea, title: e.target.value })
                }
                className="w-full px-3.5 py-2 rounded-xl border text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#352C74] mb-1">
                Solusi & Dampak Sosial
              </label>
              <textarea
                rows={3}
                required
                placeholder="Jelaskan masalah yang dipecahkan..."
                value={pitchIdea.problem}
                onChange={(e) =>
                  setPitchIdea({ ...pitchIdea, problem: e.target.value })
                }
                className="w-full px-3.5 py-2 rounded-xl border text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-[#352C74] mb-1">
                Kebutuhan Modal Awal
              </label>
              <select
                value={pitchIdea.funding}
                onChange={(e) =>
                  setPitchIdea({
                    ...pitchIdea,
                    funding: Number(e.target.value),
                  })
                }
                className="w-full px-3.5 py-2 rounded-xl border text-sm font-bold text-[#352C74]"
              >
                <option value={5000000}>Rp 5.000.000 (Tahap Validasi)</option>
                <option value={10000000}>
                  Rp 10.000.000 (Tahap Prototipe)
                </option>
                <option value={20000000}>Rp 20.000.000 (Tahap Ekspansi)</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#352C74] text-white font-extrabold text-xs hover:bg-[#9784CE] transition"
            >
              Kirim Proposal Inkubasi
            </button>
          </form>
        </div>
      </div>
    );
  }

  // 10. HELP CENTER
  const handleSendChat = (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const userMsg = chatInput;
    setChatMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setChatInput('');
    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: `Terima kasih atas pertanyaannya mengenai "${userMsg}". Tim Layanan Anggota telah mencatat tiket Anda dan saldo/status Anda dalam kondisi terverifikasi aktif.`,
        },
      ]);
    }, 450);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-6 bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-3">
        <h3 className="font-black text-lg text-[#352C74]">
          Pusat Bantuan & FAQ Anggota
        </h3>
        {[
          {
            q: 'Bagaimana cara mencairkan Simpanan Sukarela?',
            a: 'Anda dapat melakukan penarikan atau penggunaan langsung di Marketplace Koperaverse tanpa biaya admin.',
          },
          {
            q: 'Kapan Sisa Hasil Usaha (SHU) dibagikan?',
            a: 'SHU dihitung otomatis dan didistribusikan setiap selesai Rapat Anggota Tahunan (RAT).',
          },
          {
            q: 'Bagaimana cara mengunjungi gedung di Kota 3D?',
            a: 'Gunakan tombol WASD/Panah untuk berjalan atau klik langsung gedung/menu Teleport di sudut kanan atas layar 3D.',
          },
        ].map((faq, i) => (
          <div key={i} className="p-4 rounded-2xl bg-[#D1EBEF]/45">
            <h4 className="font-extrabold text-xs text-[#352C74]">{faq.q}</h4>
            <p className="text-xs text-gray-700 mt-1">{faq.a}</p>
          </div>
        ))}
      </div>

      <div className="lg:col-span-6 bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 flex flex-col justify-between h-96">
        <h3 className="font-black text-base text-[#352C74] border-b pb-2">
          Live Support KOPERAVERSE
        </h3>
        <div className="flex-1 overflow-y-auto space-y-2.5 my-3 pr-1">
          {chatMessages.map((m, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-2xl text-xs max-w-[85%] ${
                m.sender === 'user'
                  ? 'ml-auto bg-[#352C74] text-white'
                  : 'bg-[#D1EBEF] text-[#352C74] font-medium'
              }`}
            >
              {m.text}
            </div>
          ))}
        </div>
        <form onSubmit={handleSendChat} className="flex gap-2">
          <input
            type="text"
            placeholder="Ketik pertanyaan Anda..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            className="flex-1 px-3.5 py-2 rounded-xl border text-xs"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold"
          >
            Kirim
          </button>
        </form>
      </div>
    </div>
  );
}

// ============================================================================
// KOMPONEN HALAMAN PENGURUS / PENGAWAS (7 FITUR LENGKAP)
// ============================================================================
function PengurusViews({ activePage, navigateTo }) {
  const {
    members,
    applicants,
    approveApplicant,
    rejectApplicant,
    transactions,
    approveLoanTransaction,
    auditLogs,
    addAuditLog,
    showToast,
  } = useContext(AppContext);

  // Simulator SHU State
  const [totalSHU, setTotalSHU] = useState(125000000);
  const [pctJasaModal, setPctJasaModal] = useState(40);
  const [pctJasaUsaha, setPctJasaUsaha] = useState(45);
  const [shuDistributed, setShuDistributed] = useState(false);

  // Filter Audit & Laporan
  const [auditFilter, setAuditFilter] = useState('Semua');
  const [reportPeriod, setReportPeriod] = useState('Tahun Buku 2026');
  const [complianceChecks, setComplianceChecks] = useState([
    {
      id: 'c1',
      label: 'Pelaksanaan Rapat Anggota Tahunan (RAT) Tepat Waktu',
      done: true,
    },
    {
      id: 'c2',
      label: 'Rasio Likuiditas Kas di Atas Batas Sehat (148% > 125%)',
      done: true,
    },
    {
      id: 'c3',
      label: 'NPL (Kredit Bermasalah) Terkendali di Bawah 2% (Saat ini 0.8%)',
      done: true,
    },
    {
      id: 'c4',
      label: 'Audit Rekonsiliasi Saldo Simpanan Sukarela & Marketplace',
      done: false,
    },
  ]);

  const totalSimpananAll = members.reduce(
    (s, m) => s + m.simpananPokok + m.simpananWajib + m.simpananSukarela,
    0
  );

  // 1. DASHBOARD PENGURUS / PENGAWAS
  if (activePage === 'dashboard') {
    const pendingApps = applicants.filter(
      (a) => a.status === 'Menunggu Verifikasi'
    ).length;
    const pendingLoans = transactions.filter(
      (t) => t.status === 'Menunggu Persetujuan'
    ).length;

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            className="p-5 rounded-2xl text-white shadow-lg"
            style={{ backgroundColor: COLORS.deepNavy }}
          >
            <span className="text-xs text-[#D1EBEF] font-semibold">
              Total Simpanan Terkelola
            </span>
            <p className="text-2xl font-black mt-1">
              {formatRupiah(totalSimpananAll)}
            </p>
            <span className="inline-block mt-2 text-[11px] bg-white/15 px-2 py-0.5 rounded-full">
              {members.length} Anggota Aktif
            </span>
          </div>
          <div
            className="p-5 rounded-2xl text-white shadow-lg"
            style={{ backgroundColor: COLORS.purple }}
          >
            <span className="text-xs text-white/90 font-semibold">
              Calon Anggota Baru
            </span>
            <p className="text-2xl font-black mt-1">{pendingApps} Pengajuan</p>
            <button
              onClick={() => navigateTo('anggota-mgmt')}
              className="mt-2 text-[11px] underline font-bold"
            >
              Verifikasi Sekarang →
            </button>
          </div>
          <div className="p-5 rounded-2xl bg-white shadow-md border border-[#A49BE1]/40">
            <span className="text-xs text-gray-500 font-semibold">
              Pinjaman Menunggu Persetujuan
            </span>
            <p className="text-2xl font-black text-[#352C74] mt-1">
              {pendingLoans} Berkas
            </p>
            <button
              onClick={() => navigateTo('transaksi')}
              className="mt-2 text-[11px] font-bold text-[#9784CE] underline"
            >
              Tinjau Pinjaman →
            </button>
          </div>
          <div className="p-5 rounded-2xl bg-white shadow-md border border-[#A49BE1]/40">
            <span className="text-xs text-gray-500 font-semibold">
              Skor Kesehatan Koperasi
            </span>
            <p className="text-2xl font-black text-emerald-700 mt-1">
              94.5 / 100
            </p>
            <span className="inline-block mt-2 text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              Predikat: SEHAT
            </span>
          </div>
        </div>

        {/* Menu Tata Kelola Pengurus */}
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30">
          <h3 className="font-black text-lg text-[#352C74] mb-4">
            Panel Tata Kelola & Pengawasan
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              { id: 'anggota-mgmt', label: 'Manajemen Anggota', icon: Users },
              {
                id: 'transaksi',
                label: 'Transaksi & Kredit',
                icon: CreditCard,
              },
              { id: 'shu', label: 'Kalkulasi SHU', icon: PieChart },
              {
                id: 'laporan',
                label: 'Laporan Keuangan',
                icon: FileSpreadsheet,
              },
              { id: 'audit', label: 'Audit Trail', icon: History },
              { id: 'pengawasan', label: 'Pengawasan', icon: Eye },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className="p-4 rounded-2xl bg-[#D1EBEF]/35 hover:bg-[#352C74] hover:text-white text-[#352C74] transition flex flex-col items-center text-center gap-2 font-extrabold text-xs"
                >
                  <Icon className="w-6 h-6" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // 2. MANAJEMEN ANGGOTA & VERIFIKASI PENDAFTAR BARU
  if (activePage === 'anggota-mgmt') {
    return (
      <div className="space-y-6">
        {/* Antrean Verifikasi Calon Anggota dari Form Nonanggota */}
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30">
          <h3 className="font-black text-lg text-[#352C74]">
            Verifikasi Calon Anggota Baru
          </h3>
          <p className="text-xs text-gray-500 mb-4">
            Pengajuan yang masuk dari formulir pendaftaran Nonanggota dapat
            disetujui langsung menjadi anggota aktif.
          </p>
          <div className="space-y-3">
            {applicants.map((app) => (
              <div
                key={app.id}
                className="p-4 rounded-2xl border border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-[#352C74]">
                      {app.name}
                    </span>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#D1EBEF] text-[#352C74]">
                      {app.id}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-0.5">
                    Unit Usaha: <strong>{app.unitUsaha}</strong> • Setoran Awal:{' '}
                    <strong>{formatRupiah(app.setoranAwal)}</strong>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {app.status === 'Menunggu Verifikasi' ? (
                    <>
                      <button
                        onClick={() => approveApplicant(app.id)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 transition"
                      >
                        Setujui & Aktifkan
                      </button>
                      <button
                        onClick={() => rejectApplicant(app.id)}
                        className="px-3 py-2 rounded-xl bg-rose-100 text-rose-700 text-xs font-bold hover:bg-rose-200 transition"
                      >
                        Tolak
                      </button>
                    </>
                  ) : (
                    <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
                      {app.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Direktori Anggota Aktif */}
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 overflow-x-auto">
          <h3 className="font-black text-lg text-[#352C74] mb-4">
            Daftar Anggota Aktif ({members.length})
          </h3>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-gray-200 text-[#352C74]">
                <th className="py-2.5 px-3">ID</th>
                <th className="py-2.5 px-3">Nama Anggota</th>
                <th className="py-2.5 px-3">Unit Usaha</th>
                <th className="py-2.5 px-3">Total Simpanan</th>
                <th className="py-2.5 px-3">Poin</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {members.map((m) => (
                <tr
                  key={m.id}
                  className="border-b border-gray-100 hover:bg-[#D1EBEF]/25"
                >
                  <td className="py-3 px-3 font-mono font-bold text-[#352C74]">
                    {m.id}
                  </td>
                  <td className="py-3 px-3 font-bold text-[#352C74]">
                    {m.name}
                  </td>
                  <td className="py-3 px-3 text-gray-600">{m.unitUsaha}</td>
                  <td className="py-3 px-3 font-extrabold text-[#352C74]">
                    {formatRupiah(
                      m.simpananPokok + m.simpananWajib + m.simpananSukarela
                    )}
                  </td>
                  <td className="py-3 px-3 font-bold text-[#9784CE]">
                    {m.poinAktivitas}
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                      {m.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // 3. TRANSAKSI & VERIFIKASI PINJAMAN
  if (activePage === 'transaksi') {
    return (
      <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-4">
        <h3 className="font-black text-lg text-[#352C74]">
          Manajemen Transaksi & Persetujuan Kredit
        </h3>
        <div className="space-y-3">
          {transactions.map((trx) => (
            <div
              key={trx.id}
              className="p-4 rounded-2xl border border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-[#9784CE]">
                    {trx.id}
                  </span>
                  <span className="font-extrabold text-sm text-[#352C74]">
                    {trx.type}
                  </span>
                </div>
                <p className="text-xs text-gray-600 mt-0.5">
                  Anggota: <strong>{trx.member}</strong> • {trx.date}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-black text-sm text-[#352C74]">
                  {formatRupiah(Math.abs(trx.amount))}
                </span>
                {trx.status === 'Menunggu Persetujuan' ? (
                  <button
                    onClick={() => approveLoanTransaction(trx.id)}
                    className="px-4 py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
                  >
                    Setujui Pencairan
                  </button>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                    {trx.status}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 4. KALKULASI & DISTRIBUSI SHU
  if (activePage === 'shu') {
    const pctCadangan = Math.max(0, 100 - pctJasaModal - pctJasaUsaha);
    const danaJasaModal = (totalSHU * pctJasaModal) / 100;
    const danaJasaUsaha = (totalSHU * pctJasaUsaha) / 100;
    const totalPoinAll = members.reduce((s, m) => s + m.poinAktivitas, 0);

    return (
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-5">
          <div className="flex flex-wrap justify-between items-center gap-3">
            <div>
              <h3 className="font-black text-lg text-[#352C74]">
                Simulator & Distribusi Sisa Hasil Usaha (SHU)
              </h3>
              <p className="text-xs text-gray-500">
                Sesuaikan proporsi pembagian sesuai ketetapan Rapat Anggota
                Tahunan (RAT).
              </p>
            </div>
            <button
              onClick={() => {
                setShuDistributed(true);
                addAuditLog(
                  'Distribusi SHU',
                  `Mendistribusikan SHU sebesar ${formatRupiah(
                    totalSHU
                  )} ke seluruh anggota aktif`
                );
                showToast(
                  'Distribusi SHU berhasil diposting ke akun seluruh anggota!'
                );
              }}
              className="px-5 py-2.5 rounded-xl bg-[#352C74] text-white text-xs font-extrabold hover:bg-[#9784CE] transition shadow"
            >
              {shuDistributed
                ? 'SHU Telah Didistribusikan ✓'
                : 'Distribusikan SHU ke Anggota'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[#D1EBEF]/50">
              <label className="block text-xs font-bold text-[#352C74]">
                Total SHU Tahun Buku
              </label>
              <input
                type="number"
                step={5000000}
                value={totalSHU}
                onChange={(e) => setTotalSHU(Number(e.target.value))}
                className="w-full mt-1.5 px-3 py-2 rounded-xl border font-black text-sm text-[#352C74]"
              />
            </div>
            <div className="p-4 rounded-2xl bg-[#A49BE1]/20">
              <label className="block text-xs font-bold text-[#352C74]">
                Jasa Modal Simpanan ({pctJasaModal}%)
              </label>
              <input
                type="range"
                min={20}
                max={60}
                value={pctJasaModal}
                onChange={(e) => setPctJasaModal(Number(e.target.value))}
                className="w-full mt-2 accent-[#352C74]"
              />
              <p className="text-xs font-extrabold text-[#352C74] mt-1">
                {formatRupiah(danaJasaModal)}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-[#9784CE]/20">
              <label className="block text-xs font-bold text-[#352C74]">
                Jasa Transaksi Usaha ({pctJasaUsaha}%)
              </label>
              <input
                type="range"
                min={20}
                max={60}
                value={pctJasaUsaha}
                onChange={(e) => setPctJasaUsaha(Number(e.target.value))}
                className="w-full mt-2 accent-[#352C74]"
              />
              <p className="text-xs font-extrabold text-[#352C74] mt-1">
                {formatRupiah(danaJasaUsaha)} • Cadangan: {pctCadangan}%
              </p>
            </div>
          </div>

          {/* Rincian Per Anggota */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b text-[#352C74]">
                  <th className="py-2 px-3">Anggota</th>
                  <th className="py-2 px-3">Porsi Jasa Modal</th>
                  <th className="py-2 px-3">Porsi Jasa Usaha</th>
                  <th className="py-2 px-3">Total SHU Diterima</th>
                </tr>
              </thead>
              <tbody>
                {members.map((m) => {
                  const mSimpanan =
                    m.simpananPokok + m.simpananWajib + m.simpananSukarela;
                  const bagianModal =
                    (mSimpanan / totalSimpananAll) * danaJasaModal;
                  const bagianUsaha =
                    (m.poinAktivitas / totalPoinAll) * danaJasaUsaha;
                  return (
                    <tr key={m.id} className="border-b border-gray-100">
                      <td className="py-3 px-3 font-bold text-[#352C74]">
                        {m.name}
                      </td>
                      <td className="py-3 px-3">
                        {formatRupiah(Math.round(bagianModal))}
                      </td>
                      <td className="py-3 px-3">
                        {formatRupiah(Math.round(bagianUsaha))}
                      </td>
                      <td className="py-3 px-3 font-black text-emerald-700">
                        {formatRupiah(Math.round(bagianModal + bagianUsaha))}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // 5. LAPORAN KEUANGAN
  if (activePage === 'laporan') {
    return (
      <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-5">
        <div className="flex flex-wrap justify-between items-center gap-3">
          <div>
            <h3 className="font-black text-lg text-[#352C74]">
              Laporan Keuangan Koperasi (Neraca & PHU)
            </h3>
            <p className="text-xs text-gray-500">
              Standar Akuntansi Entitas Tanpa Akuntabilitas Publik (SAK ETAP /
              EP).
            </p>
          </div>
          <div className="flex gap-2">
            <select
              value={reportPeriod}
              onChange={(e) => setReportPeriod(e.target.value)}
              className="px-3 py-2 rounded-xl border text-xs font-bold text-[#352C74]"
            >
              <option>Tahun Buku 2026</option>
              <option>Kuartal III 2026</option>
              <option>Tahun Buku 2025</option>
            </select>
            <button
              onClick={() =>
                showToast(
                  `Laporan Keuangan (${reportPeriod}) berhasil diunduh dalam format PDF/CSV.`
                )
              }
              className="px-4 py-2 rounded-xl bg-[#352C74] text-white text-xs font-bold hover:bg-[#9784CE] transition"
            >
              Unduh Laporan
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="p-5 rounded-2xl bg-[#D1EBEF]/45 space-y-2.5">
            <h4 className="font-extrabold text-sm text-[#352C74] border-b border-[#352C74]/20 pb-2">
              Neraca Aset & Kewajiban ({reportPeriod})
            </h4>
            <div className="flex justify-between text-xs">
              <span>Kas & Setara Kas</span>
              <strong>Rp 1.850.000.000</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span>Piutang Pinjaman Anggota</span>
              <strong>Rp 2.420.000.000</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span>Aset Tetap & Infrastruktur Digital</span>
              <strong>Rp 580.000.000</strong>
            </div>
            <div className="flex justify-between text-sm font-black text-[#352C74] pt-2 border-t">
              <span>Total Aktiva</span>
              <span>Rp 4.850.000.000</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#A49BE1]/15 space-y-2.5">
            <h4 className="font-extrabold text-sm text-[#352C74] border-b border-[#352C74]/20 pb-2">
              Perhitungan Hasil Usaha (PHU)
            </h4>
            <div className="flex justify-between text-xs">
              <span>Pendapatan Jasa Pinjaman</span>
              <strong>Rp 210.400.000</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span>Margin Transaksi Marketplace</span>
              <strong>Rp 84.600.000</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span>Beban Operasional & Akademi</span>
              <strong>(Rp 170.000.000)</strong>
            </div>
            <div className="flex justify-between text-sm font-black text-emerald-700 pt-2 border-t">
              <span>Sisa Hasil Usaha (SHU) Bersih</span>
              <span>Rp 125.000.000</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 6. AUDIT TRAIL
  if (activePage === 'audit') {
    const filteredLogs = auditLogs.filter(
      (l) => auditFilter === 'Semua' || l.module.includes(auditFilter)
    );
    return (
      <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-4">
        <div className="flex flex-wrap justify-between items-center gap-3">
          <h3 className="font-black text-lg text-[#352C74]">
            Audit Trail & Log Aktivitas Sistem
          </h3>
          <select
            value={auditFilter}
            onChange={(e) => setAuditFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border text-xs font-bold text-[#352C74]"
          >
            <option value="Semua">Semua Modul</option>
            <option value="Financial">Financial Center</option>
            <option value="Marketplace">Marketplace</option>
            <option value="Pendaftaran">Pendaftaran</option>
            <option value="SHU">SHU & Keuangan</option>
          </select>
        </div>

        <div className="space-y-2.5">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              className="p-3.5 rounded-2xl border border-gray-100 bg-gray-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] font-bold text-[#9784CE]">
                    {log.id}
                  </span>
                  <span className="text-xs font-extrabold text-[#352C74]">
                    {log.action}
                  </span>
                </div>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  Aktor: {log.actor} • Modul: {log.module} • {log.time}
                </p>
              </div>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#D1EBEF] text-[#352C74] w-fit">
                {log.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 7. PENGAWASAN & KEPATUHAN
  return (
    <div className="bg-white p-6 rounded-3xl shadow-md border border-[#A49BE1]/30 space-y-5">
      <div>
        <h3 className="font-black text-lg text-[#352C74]">
          Dewan Pengawas: Checklist Kepatuhan & Tata Kelola
        </h3>
        <p className="text-xs text-gray-500">
          Klik item pemeriksaan untuk memperbarui status pengawasan berkala.
        </p>
      </div>
      <div className="space-y-3">
        {complianceChecks.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setComplianceChecks((prev) =>
                prev.map((c) =>
                  c.id === item.id ? { ...c, done: !c.done } : c
                )
              );
              addAuditLog(
                'Pengawasan',
                `Memperbarui status kepatuhan: ${item.label}`
              );
            }}
            className={`w-full p-4 rounded-2xl border-2 text-left flex items-center justify-between transition ${
              item.done
                ? 'border-emerald-500 bg-emerald-50/60'
                : 'border-amber-400 bg-amber-50/50'
            }`}
          >
            <span className="font-bold text-xs sm:text-sm text-[#352C74]">
              {item.label}
            </span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                item.done
                  ? 'bg-emerald-600 text-white'
                  : 'bg-amber-500 text-white'
              }`}
            >
              {item.done ? 'Terpenuhi ✓' : 'Dalam Tinjauan'}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// KOMPONEN UTAMA APLIKASI KOPERAVERSE
// ============================================================================
export default function App() {
  // Auth & Navigation State
  const [userSession, setUserSession] = useState(null); // null = layar login
  const [viewMode, setViewMode] = useState('3d'); // '3d' | 'app'
  const [activePage, setActivePage] = useState('dashboard');
  const [navHistory, setNavHistory] = useState([]);
  const [teleportTarget, setTeleportTarget] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Shared Domain Data State (Terhubung antar seluruh role)
  const [members, setMembers] = useState(INITIAL_MEMBERS);
  const [activeMemberId, setActiveMemberId] = useState('MBR-001');
  const [applicants, setApplicants] = useState(INITIAL_APPLICANTS);
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [courses, setCourses] = useState(INITIAL_COURSES);
  const [transactions, setTransactions] = useState(INITIAL_TRANSACTIONS);
  const [polls, setPolls] = useState(INITIAL_POLLS);
  const [posts, setPosts] = useState(INITIAL_COMMUNITY_POSTS);
  const [mentors, setMentors] = useState(INITIAL_MENTORS);
  const [auditLogs, setAuditLogs] = useState(INITIAL_AUDIT_LOGS);

  const currentMember = useMemo(
    () => members.find((m) => m.id === activeMemberId) || members[0],
    [members, activeMemberId]
  );

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3600);
  };

  const addAuditLog = (module, action, status = 'Valid') => {
    const newLog = {
      id: `AUD-${Math.floor(106 + Math.random() * 890)}`,
      time: new Date().toISOString().slice(0, 16).replace('T', ' '),
      actor: `${userSession?.name || 'Pengguna'} (${
        userSession?.role || 'sistem'
      })`,
      module,
      action,
      status,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Navigasi dengan riwayat (Back button support)
  const navigateTo = (page, switchToAppMode = true) => {
    if (page !== activePage) {
      setNavHistory((prev) => [...prev, { page: activePage, mode: viewMode }]);
      setActivePage(page);
    }
    if (switchToAppMode) {
      setViewMode('app');
    }
    setMobileMenuOpen(false);
  };

  const handleGoBack = () => {
    if (navHistory.length === 0) {
      setViewMode('3d');
      return;
    }
    const last = navHistory[navHistory.length - 1];
    setNavHistory((prev) => prev.slice(0, -1));
    setActivePage(last.page);
    setViewMode(last.mode);
  };

  const handleLogin = ({ role, name, email }) => {
    setUserSession({ role, name, email });
    setNavHistory([]);
    if (role === 'nonanggota') {
      setActivePage('beranda');
      setViewMode('3d');
    } else if (role === 'anggota') {
      setActivePage('dashboard');
      setViewMode('3d');
    } else {
      setActivePage('dashboard');
      setViewMode('app');
    }
    showToast(`Selamat datang, ${name} (${role.toUpperCase()})!`);
  };

  const switchRoleQuick = (newRole, customName) => {
    const defaultNames = {
      nonanggota: 'Pengunjung Koperaverse',
      anggota: 'Raka Pratama',
      pengurus: 'Dewan Pengurus Utama',
    };
    handleLogin({
      role: newRole,
      name: customName || defaultNames[newRole],
      email: `${newRole}@koperaverse.id`,
    });
  };

  // Handler Interaksi Gedung 3D
  const handleEnterBuilding3D = (building) => {
    if (!userSession) return;
    if (userSession.role === 'nonanggota') {
      navigateTo(building.guestPage, true);
      showToast(`Memasuki ${building.shortName} (Mode Pengunjung)`);
    } else if (userSession.role === 'anggota') {
      navigateTo(building.pageTarget, true);
      showToast(`Memasuki interior ${building.name}`);
    } else {
      // Pengurus diarahkan ke modul manajemen relevan
      const pengurusMap = {
        'my-coop': 'anggota-mgmt',
        financial: 'transaksi',
        marketplace: 'laporan',
        academy: 'pengawasan',
        assembly: 'shu',
        'youth-hub': 'audit',
      };
      navigateTo(pengurusMap[building.id] || 'dashboard', true);
      showToast(`Membuka panel pengelolaan ${building.shortName}`);
    }
  };

  // Domain Mutations
  const updateAvatar = (patch) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.id === currentMember.id
          ? { ...m, avatar: { ...m.avatar, ...patch } }
          : m
      )
    );
    showToast('Tampilan Avatar diperbarui!');
  };

  const addSavingDeposit = (amount) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.id === currentMember.id
          ? {
              ...m,
              simpananSukarela: m.simpananSukarela + amount,
              poinAktivitas: m.poinAktivitas + 50,
            }
          : m
      )
    );
    setTransactions((prev) => [
      {
        id: `TRX-${Math.floor(910 + Math.random() * 89)}`,
        date: 'Baru saja',
        member: currentMember.name,
        type: 'Setoran Simpanan Sukarela',
        amount,
        status: 'Selesai',
      },
      ...prev,
    ]);
    addAuditLog(
      'Financial Center',
      `Setoran Simpanan Sukarela ${formatRupiah(amount)}`
    );
    showToast(`Berhasil menyetor ${formatRupiah(amount)} (+50 Poin)!`);
  };

  const requestLoan = ({ amount, tenor, purpose }) => {
    setTransactions((prev) => [
      {
        id: `TRX-${Math.floor(910 + Math.random() * 89)}`,
        date: 'Baru saja',
        member: currentMember.name,
        type: `Pinjaman (${tenor} bln): ${purpose}`,
        amount,
        status: 'Menunggu Persetujuan',
      },
      ...prev,
    ]);
    addAuditLog(
      'Financial Center',
      `Pengajuan pinjaman ${formatRupiah(amount)} (${tenor} bulan)`,
      'Pending Review'
    );
    showToast('Pengajuan pinjaman dikirim! Menunggu persetujuan Pengurus.');
  };

  const approveLoanTransaction = (trxId) => {
    const targetTrx = transactions.find((t) => t.id === trxId);
    setTransactions((prev) =>
      prev.map((t) => (t.id === trxId ? { ...t, status: 'Disetujui' } : t))
    );
    if (targetTrx) {
      setMembers((prev) =>
        prev.map((m) =>
          m.name === targetTrx.member
            ? { ...m, pinjamanAktif: m.pinjamanAktif + targetTrx.amount }
            : m
        )
      );
      addAuditLog(
        'Transaksi & Kredit',
        `Menyetujui pencairan pinjaman ${trxId} sebesar ${formatRupiah(
          targetTrx.amount
        )}`
      );
      showToast(
        `Pinjaman ${trxId} disetujui & saldo pinjaman anggota diperbarui!`
      );
    }
  };

  const checkoutCart = (totalAmount, itemNames) => {
    if (currentMember.simpananSukarela < totalAmount) {
      showToast(
        'Saldo Simpanan Sukarela tidak mencukupi. Silakan setor di My Cooperative.'
      );
      return false;
    }
    setMembers((prev) =>
      prev.map((m) =>
        m.id === currentMember.id
          ? {
              ...m,
              simpananSukarela: m.simpananSukarela - totalAmount,
              poinAktivitas: m.poinAktivitas + 80,
            }
          : m
      )
    );
    setTransactions((prev) => [
      {
        id: `TRX-${Math.floor(910 + Math.random() * 89)}`,
        date: 'Baru saja',
        member: currentMember.name,
        type: `Belanja Marketplace (${itemNames})`,
        amount: -totalAmount,
        status: 'Selesai',
      },
      ...prev,
    ]);
    addAuditLog(
      'Marketplace',
      `Checkout produk senilai ${formatRupiah(totalAmount)}`
    );
    showToast(
      `Pembayaran ${formatRupiah(totalAmount)} berhasil! (+80 Poin Aktivitas)`
    );
    return true;
  };

  const addProduct = (prod) => {
    const newItem = {
      id: `PRD-${Math.floor(10 + Math.random() * 89)}`,
      name: prod.name,
      seller: currentMember.name,
      category: prod.category,
      price: prod.price,
      stock: prod.stock,
      rating: 5.0,
      badge: 'Baru',
      color: '#352C74',
      desc: prod.desc || 'Produk unggulan anggota koperasi KOPERAVERSE.',
    };
    setProducts((prev) => [newItem, ...prev]);
    addAuditLog('Marketplace', `Menambahkan produk baru: ${prod.name}`);
    showToast(`Produk "${prod.name}" tayang di Marketplace!`);
  };

  const enrollOrAdvanceCourse = (courseId) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id !== courseId) return c;
        if (!c.enrolled) {
          showToast(`Berhasil mendaftar pelatihan: ${c.title}`);
          return { ...c, enrolled: true, progress: 20 };
        }
        const nextProg = Math.min(100, c.progress + 40);
        if (nextProg === 100 && c.progress < 100) {
          setMembers((mList) =>
            mList.map((m) =>
              m.id === currentMember.id
                ? { ...m, poinAktivitas: m.poinAktivitas + c.points }
                : m
            )
          );
          showToast(
            `Selamat! Pelatihan selesai & +${c.points} Poin ditambahkan!`
          );
        } else {
          showToast(`Progres belajar diperbarui menjadi ${nextProg}%`);
        }
        return { ...c, progress: nextProg };
      })
    );
  };

  const castVote = (pollId, optionId) => {
    setPolls((prev) =>
      prev.map((p) => {
        if (p.id !== pollId) return p;
        const already = p.votedOption;
        return {
          ...p,
          votedOption: optionId,
          options: p.options.map((o) => {
            if (o.id === optionId && already !== optionId)
              return { ...o, votes: o.votes + 1 };
            if (o.id === already && already !== optionId)
              return { ...o, votes: Math.max(0, o.votes - 1) };
            return o;
          }),
        };
      })
    );
    addAuditLog(
      'Assembly Hall',
      `Memberikan suara e-voting pada agenda ${pollId}`
    );
    showToast('Suara musyawarah Anda berhasil direkam!');
  };

  const addPost = (content, group) => {
    setPosts((prev) => [
      {
        id: `POST-${Date.now()}`,
        author: currentMember.name,
        badge: currentMember.avatar.title,
        time: 'Baru saja',
        group,
        content,
        likes: 1,
        liked: true,
        comments: [],
      },
      ...prev,
    ]);
    showToast('Postingan berhasil diterbitkan ke Community Hub!');
  };

  const toggleLikePost = (postId) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              liked: !p.liked,
              likes: p.liked ? p.likes - 1 : p.likes + 1,
            }
          : p
      )
    );
  };

  const addCommentPost = (postId, text) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: [...p.comments, { author: currentMember.name, text }],
            }
          : p
      )
    );
  };

  const bookMentorSlot = (mentorId, slot) => {
    setMentors((prev) =>
      prev.map((m) => (m.id === mentorId ? { ...m, booked: slot } : m))
    );
    addAuditLog('Youth Hub', `Booking sesi mentoring jadwal ${slot}`);
    showToast(`Sesi mentoring berhasil dijadwalkan pada ${slot}!`);
  };

  const registerApplicant = (form) => {
    const newApp = {
      id: `REG-2026-0${applicants.length + 1}`,
      ...form,
      tanggalDaftar: '2026-11-13',
      status: 'Menunggu Verifikasi',
    };
    setApplicants((prev) => [newApp, ...prev]);
    addAuditLog(
      'Pendaftaran',
      `Pengajuan calon anggota baru: ${form.name}`,
      'Pending Review'
    );
    showToast('Formulir pendaftaran terkirim ke Pengurus!');
    return newApp;
  };

  const approveApplicant = (appId) => {
    const app = applicants.find((a) => a.id === appId);
    if (!app) return;
    setApplicants((prev) =>
      prev.map((a) =>
        a.id === appId ? { ...a, status: 'Disetujui (Aktif)' } : a
      )
    );
    const newMember = {
      id: `MBR-00${members.length + 1}`,
      name: app.name,
      email: app.email,
      phone: app.phone,
      joinDate: '2026-11-13',
      status: 'Aktif',
      unitUsaha: app.unitUsaha,
      simpananPokok: 1000000,
      simpananWajib: 0,
      simpananSukarela: Math.max(0, app.setoranAwal - 1000000),
      pinjamanAktif: 0,
      poinAktivitas: 100,
      avatar: {
        skin: '#F5CBA7',
        shirt: '#A49BE1',
        pants: '#352C74',
        hair: '#2C221E',
        hat: 'none',
        title: 'Anggota Baru',
      },
    };
    setMembers((prev) => [...prev, newMember]);
    addAuditLog(
      'Manajemen Anggota',
      `Menyetujui keanggotaan baru: ${app.name} (${newMember.id})`
    );
    showToast(`${app.name} resmi diaktifkan sebagai Anggota Koperasi!`);
  };

  const rejectApplicant = (appId) => {
    setApplicants((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status: 'Ditolak' } : a))
    );
    showToast('Pengajuan ditandai ditolak.');
  };

  // Tampilkan layar login jika belum masuk
  if (!userSession) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  // Definisi Menu Navigasi Berdasarkan Role
  const roleMenus = {
    nonanggota: [
      { id: 'beranda', label: 'Beranda', icon: Home },
      { id: 'info', label: 'Info Koperasi', icon: Building2 },
      { id: 'katalog', label: 'Katalog Produk', icon: ShoppingBag },
      { id: 'edukasi', label: 'Edukasi', icon: BookOpen },
      { id: 'daftar', label: 'Daftar Anggota', icon: UserCheck },
    ],
    anggota: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'avatar', label: 'Avatar', icon: User },
      { id: 'my-coop', label: 'My Cooperative', icon: Building2 },
      { id: 'financial', label: 'Financial Center', icon: Wallet },
      { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag },
      { id: 'academy', label: 'Academy', icon: GraduationCap },
      { id: 'assembly', label: 'Assembly Hall', icon: Vote },
      { id: 'community', label: 'Community Hub', icon: MessageSquare },
      { id: 'youth', label: 'Youth Hub', icon: Rocket },
      { id: 'help', label: 'Help Center', icon: HelpCircle },
    ],
    pengurus: [
      { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
      { id: 'anggota-mgmt', label: 'Manajemen Anggota', icon: Users },
      { id: 'transaksi', label: 'Transaksi & Kredit', icon: CreditCard },
      { id: 'shu', label: 'SHU', icon: PieChart },
      { id: 'laporan', label: 'Laporan Keuangan', icon: FileSpreadsheet },
      { id: 'audit', label: 'Audit Trail', icon: History },
      { id: 'pengawasan', label: 'Pengawasan', icon: Eye },
    ],
  };

  const currentMenus = roleMenus[userSession.role] || [];

  return (
    <AppContext.Provider
      value={{
        members,
        currentMember,
        updateAvatar,
        addSavingDeposit,
        requestLoan,
        transactions,
        approveLoanTransaction,
        products,
        addProduct,
        checkoutCart,
        courses,
        enrollOrAdvanceCourse,
        polls,
        castVote,
        posts,
        addPost,
        toggleLikePost,
        addCommentPost,
        mentors,
        bookMentorSlot,
        applicants,
        registerApplicant,
        approveApplicant,
        rejectApplicant,
        auditLogs,
        addAuditLog,
        showToast,
      }}
    >
      <div
        className="min-h-screen flex flex-col"
        style={{ backgroundColor: '#F3F1FC' }}
      >
        {/* HEADER NAVIGASI UTAMA */}
        <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#A49BE1]/40 shadow-xs">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
            {/* Kiri: Tombol Kembali, Beranda & Brand */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={handleGoBack}
                title="Kembali ke Halaman Sebelumnya"
                className="p-2 rounded-xl bg-[#D1EBEF] text-[#352C74] hover:bg-[#9784CE] hover:text-white transition"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setViewMode('3d');
                }}
                title="Beranda Kota Virtual 3D"
                className="flex items-center gap-2 text-left"
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-black shadow"
                  style={{ backgroundColor: COLORS.deepNavy }}
                >
                  K
                </div>
                <div>
                  <h1 className="font-black text-sm sm:text-base tracking-tight text-[#352C74] leading-none">
                    KOPERAVERSE
                  </h1>
                  <span className="text-[10px] font-bold text-[#9784CE]">
                    Digital Cooperative City
                  </span>
                </div>
              </button>
            </div>

            {/* Tengah: Toggle Mode Kota 3D vs Mode Fitur Dashboard */}
            <div className="flex items-center bg-[#D1EBEF]/70 p-1 rounded-2xl border border-[#A49BE1]/40">
              <button
                onClick={() => setViewMode('3d')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                  viewMode === '3d'
                    ? 'bg-[#352C74] text-white shadow'
                    : 'text-[#352C74] hover:bg-white/60'
                }`}
              >
                <Gamepad2 className="w-3.5 h-3.5" />
                <span>Kota 3D</span>
              </button>
              <button
                onClick={() => setViewMode('app')}
                className={`px-3 sm:px-4 py-1.5 rounded-xl text-xs font-extrabold transition flex items-center gap-1.5 ${
                  viewMode === 'app'
                    ? 'bg-[#352C74] text-white shadow'
                    : 'text-[#352C74] hover:bg-white/60'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>Menu Fitur</span>
              </button>
            </div>

            {/* Kanan: Instant Role Switcher & Logout */}
            <div className="flex items-center gap-2">
              <select
                aria-label="Ganti Role Simulasi"
                value={userSession.role}
                onChange={(e) => switchRoleQuick(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl border border-[#9784CE] bg-[#D1EBEF]/40 text-xs font-extrabold text-[#352C74] focus:outline-none"
              >
                <option value="nonanggota">Role: Nonanggota</option>
                <option value="anggota">Role: Anggota</option>
                <option value="pengurus">Role: Pengurus</option>
              </select>

              <button
                onClick={() => setUserSession(null)}
                title="Logout / Layar Login"
                className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-600 hover:text-white text-xs font-bold transition flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>

          {/* Sub-Navigasi Menu Fitur Sesuai Role */}
          <div className="bg-white border-t border-gray-100">
            <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {currentMenus.map((m) => {
                const Icon = m.icon;
                const isActive = viewMode === 'app' && activePage === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => navigateTo(m.id, true)}
                    className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-[#352C74] text-white shadow-xs'
                        : 'text-[#352C74] hover:bg-[#D1EBEF]/70'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </header>

        {/* TOAST NOTIFIKASI INTERAKSI */}
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 bg-[#352C74] text-white px-4 py-3 rounded-2xl shadow-2xl border-2 border-[#D1EBEF] flex items-center gap-2.5 text-xs font-bold max-w-sm">
            <Sparkles className="w-4 h-4 text-[#D1EBEF] shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* KONTEN UTAMA: KOTA 3D ATAU HALAMAN FITUR ROLE */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-5 space-y-5">
          {viewMode === '3d' ? (
            <div className="space-y-4">
              <Koperaverse3DWorld
                avatarConfig={currentMember.avatar}
                onEnterBuilding={handleEnterBuilding3D}
                teleportTarget={teleportTarget}
                clearTeleport={() => setTeleportTarget(null)}
                currentRole={userSession.role}
              />

              {/* Strip Akses Cepat Gedung & Fitur di Bawah Layar 3D */}
              <div className="bg-white p-4 rounded-3xl shadow-md border border-[#A49BE1]/30">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-[#352C74]">
                    Akses Langsung Gedung & Fitur (
                    {userSession.role.toUpperCase()})
                  </span>
                  <span className="text-xs text-gray-500">
                    Klik kartu gedung di bawah untuk langsung masuk ke fitur
                    interiornya
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                  {CITY_BUILDINGS.map((b) => (
                    <button
                      key={b.id}
                      onClick={() => handleEnterBuilding3D(b)}
                      className="p-3 rounded-2xl bg-[#D1EBEF]/45 hover:bg-[#352C74] hover:text-white text-[#352C74] transition text-left"
                    >
                      <p className="font-extrabold text-xs truncate">
                        {b.shortName}
                      </p>
                      <p className="text-[10px] opacity-80 truncate mt-0.5">
                        {b.desc}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div>
              {userSession.role === 'nonanggota' && (
                <NonanggotaViews
                  activePage={activePage}
                  navigateTo={(p) => navigateTo(p, true)}
                  switchRoleAndLogin={switchRoleQuick}
                />
              )}
              {userSession.role === 'anggota' && (
                <AnggotaViews
                  activePage={activePage}
                  navigateTo={(p) => navigateTo(p, true)}
                  open3DWithTeleport={(bId) => {
                    setTeleportTarget(bId);
                    setViewMode('3d');
                  }}
                />
              )}
              {userSession.role === 'pengurus' && (
                <PengurusViews
                  activePage={activePage}
                  navigateTo={(p) => navigateTo(p, true)}
                />
              )}
            </div>
          )}
        </main>
      </div>
    </AppContext.Provider>
  );
}
